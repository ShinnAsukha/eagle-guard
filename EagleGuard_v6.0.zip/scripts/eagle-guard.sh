#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════════╗
# ║  EAGLE GUARD v6.0 — Enterprise DDoS Protection Engine               ║
# ║                                                                      ║
# ║  Katmanlar:                                                          ║
# ║  [1] mangle/PREROUTING  — En erken filtreleme (kernel öncesi)       ║
# ║  [2] SYNPROXY            — SYN flood (10x kapasite artışı)          ║
# ║  [3] L4 Network          — TCP/UDP/ICMP/Flood koruması              ║
# ║  [4] L7 Application      — HTTP/SSH/FTP brute force                 ║
# ║  [5] GAME Layer          — Oyun sunucusu UDP/TCP flood              ║
# ║  [6] Suricata IDS/IPS    — Gerçek zamanlı tehdit tespiti           ║
# ║  [7] GeoIP Blocking      — Ülke bazlı engelleme                    ║
# ║  [8] Trafik Analizi      — İstatistiksel anomali tespiti            ║
# ║  [9] Fail2ban            — Log bazlı otomatik ban                   ║
# ║ [10] Nginx Rate Limit    — HTTP flood koruması                      ║
# ║ [11] Raporlama           — Detaylı saldırı vektör analizi          ║
# ╚══════════════════════════════════════════════════════════════════════╝
EAGLE_DIR="/opt/eagle-guard"
LOG="$EAGLE_DIR/logs/eagle.log"
LOG_ATTACK="$EAGLE_DIR/logs/attack.log"
LOG_GEO="$EAGLE_DIR/logs/geoip.log"
STATS="$EAGLE_DIR/data/stats.json"
BLOCKED="$EAGLE_DIR/data/blocked.json"
ALERTS="$EAGLE_DIR/data/alerts.json"
TRAFFIC="$EAGLE_DIR/data/traffic.json"
REPORT="$EAGLE_DIR/data/report.json"
ATTACK_DB="$EAGLE_DIR/data/attack_vectors.json"
GEOIP_DB="$EAGLE_DIR/config/geoip_blocked.txt"
CONF="$EAGLE_DIR/config/eagle.conf"
WL="$EAGLE_DIR/config/whitelist.txt"
SURICATA_RULES="$EAGLE_DIR/config/suricata-eagle.rules"
F2B_CONF="/etc/fail2ban/jail.d/eagle-guard.conf"
NGINX_CONF="/etc/nginx/conf.d/eagle-guard-ratelimit.conf"
PID="/var/run/eagle-guard.pid"
R='\033[0;31m' G='\033[0;32m' Y='\033[1;33m' C='\033[0;36m' W='\033[1;37m' N='\033[0m'

# ── Config varsayılanları ─────────────────────────────────────────────
load_conf() {
    # ── mangle/PREROUTING ──────────────────────────────────────────
    MANGLE_ENABLED=yes

    # ── SYNPROXY ───────────────────────────────────────────────────
    SYNPROXY_ENABLED=yes
    SYNPROXY_MSS=1460
    SYNPROXY_WSCALE=7
    # SYNPROXY uygulanacak portlar (boşsa tüm portlar)
    SYNPROXY_PORTS="80,443,27015,25565,7777,30120"

    # ── Layer 4 ────────────────────────────────────────────────────
    L4_SYN_RATE=200
    L4_SYN_BURST=1000
    L4_SYN_PER_IP=40
    L4_ICMP_RATE=100
    L4_CONN_PER_IP=300
    L4_UDP_PPS=500          # Genel UDP rate (oyun portları hariç)
    L4_TTL_MIN=20           # TTL anomali tespiti (saldırı araçları genelde düşük TTL)
    L4_MSS_CHECK=yes        # Şüpheli MSS değerlerini engelle

    # ── Layer 7 ────────────────────────────────────────────────────
    L7_HTTP_CONN=100
    L7_HTTP_RATE=80
    L7_SSH_RATE=6

    # ── GeoIP ──────────────────────────────────────────────────────
    GEOIP_ENABLED=no        # Aktif etmek için: yes
    GEOIP_BLOCK_COUNTRIES="" # "CN RU KP" gibi — boşlukla ayır
    GEOIP_ALLOW_ONLY=""     # Sadece bu ülkelere izin ver (BLOCK yerine)

    # ── Trafik Anomali Analizi ─────────────────────────────────────
    ANOMALY_ENABLED=yes
    ANOMALY_PPS_THRESHOLD=15000    # Saniyede paket eşiği
    ANOMALY_BPS_THRESHOLD=209715200 # Bant genişliği eşiği (200MB/s)
    ANOMALY_CONN_THRESHOLD=8000     # Eş zamanlı bağlantı eşiği
    ANOMALY_NEW_CONN_RATE=500       # Saniyede yeni bağlantı eşiği
    ANOMALY_WINDOW=10               # Analiz penceresi (saniye)
    ANOMALY_AUTOBLOCK=yes           # Anomali tespit → otomatik ban

    # ── Suricata IDS/IPS ───────────────────────────────────────────
    SURICATA_ENABLED=yes
    SURICATA_MODE=ips       # ids (sadece tespit) veya ips (engelle)
    SURICATA_IFACE=""       # Boş = otomatik tespit

    # ── Game Layer ─────────────────────────────────────────────────
    GAME_ENABLED=yes
    GAME_UDP_PPS=3000
    GAME_UDP_BURST=8000
    GAME_TCP_CONN=80
    GAME_PORTS_UDP="27015,27016,27017,27018,7777,7778,19132,19133,25565,25575,2302,2303,9987,30120,64090,2456,2457,28015"
    GAME_PORTS_TCP="27015,27016,7777,25565,25575,2302,30120,64090,9987,28015"

    # ── Fail2ban ───────────────────────────────────────────────────
    F2B_ENABLED=yes
    F2B_SSH_MAXRETRY=5
    F2B_SSH_BANTIME=3600
    F2B_HTTP_MAXRETRY=100
    F2B_HTTP_BANTIME=600
    F2B_FINDTIME=60
    F2B_RECIDIVE=yes        # Tekrarlayan saldırganlar için uzun ban
    F2B_RECIDIVE_BANTIME=86400  # 24 saat

    # ── Nginx ──────────────────────────────────────────────────────
    NGINX_ENABLED=yes
    NGINX_REQ_RATE="10r/s"
    NGINX_BURST=20
    NGINX_CONN_PER_IP=50

    # ── Bildirimler ────────────────────────────────────────────────
    DISCORD_WEBHOOK=""
    TELEGRAM_BOT=""
    TELEGRAM_CHAT=""
    EMAIL_TO=""
    EMAIL_FROM="eagle-guard@$(hostname -f 2>/dev/null || echo localhost)"

    # ── Raporlama ──────────────────────────────────────────────────
    REPORT_ENABLED=yes
    REPORT_INTERVAL=86400

    # ── Genel ──────────────────────────────────────────────────────
    BAN_TIME=3600
    INTERVAL=3
    AUTO_BLOCK=yes
    AUTOBLOCK_HITS=20

    [[ -f "$CONF" ]] && source "$CONF" 2>/dev/null || true
}

# ── Log ───────────────────────────────────────────────────────────────
log() {
    local l=$1; shift
    mkdir -p "$EAGLE_DIR/logs" 2>/dev/null
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$l] $*" >> "$LOG"
    case $l in
        ALERT) echo -e "${R}[ALERT]${N} $*" ;;
        OK)    echo -e "${G}[OK]${N}    $*" ;;
        INFO)  echo -e "${C}[INFO]${N}  $*" ;;
        WARN)  echo -e "${Y}[WARN]${N}  $*" ;;
        GAME)  echo -e "${C}[GAME]${N}  $*" ;;
        F2B)   echo -e "${Y}[F2B]${N}   $*" ;;
        NGX)   echo -e "${C}[NGX]${N}   $*" ;;
        RPT)   echo -e "${G}[RPT]${N}   $*" ;;
        GEO)   echo -e "${Y}[GEO]${N}   $*" ;;
        IDS)   echo -e "${R}[IDS]${N}   $*" ;;
        MANGLE) echo -e "${C}[MNG]${N}  $*" ;;
        PROXY) echo -e "${G}[SYP]${N}   $*" ;;
    esac
}

log_attack() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_ATTACK"
}

# ── Init ──────────────────────────────────────────────────────────────
setup() {
    mkdir -p "$EAGLE_DIR"/{logs,data,config}
    [[ ! -f "$WL" ]]         && printf "127.0.0.1\n::1\n" > "$WL"
    [[ ! -f "$BLOCKED" ]]    && echo '{"blocked":[]}' > "$BLOCKED"
    [[ ! -f "$ALERTS" ]]     && echo '{"alerts":[]}' > "$ALERTS"
    [[ ! -f "$TRAFFIC" ]]    && echo '{"points":[]}' > "$TRAFFIC"
    [[ ! -f "$REPORT" ]]     && echo '{"reports":[]}' > "$REPORT"
    [[ ! -f "$ATTACK_DB" ]]  && echo '{"vectors":[]}' > "$ATTACK_DB"
    [[ ! -f "$GEOIP_DB" ]]   && touch "$GEOIP_DB"

    # Varsayılan config oluştur
    [[ ! -f "$CONF" ]] && cat > "$CONF" << 'DEFCONF'
MANGLE_ENABLED=yes
SYNPROXY_ENABLED=yes
SYNPROXY_PORTS=80,443,27015,25565,7777,30120
L4_SYN_RATE=200
L4_SYN_BURST=1000
L4_SYN_PER_IP=40
L4_ICMP_RATE=100
L4_CONN_PER_IP=300
L4_UDP_PPS=500
L4_TTL_MIN=20
L4_MSS_CHECK=yes
L7_HTTP_CONN=100
L7_HTTP_RATE=80
L7_SSH_RATE=6
GEOIP_ENABLED=no
GEOIP_BLOCK_COUNTRIES=
GEOIP_ALLOW_ONLY=
ANOMALY_ENABLED=yes
ANOMALY_PPS_THRESHOLD=15000
ANOMALY_BPS_THRESHOLD=209715200
ANOMALY_CONN_THRESHOLD=8000
ANOMALY_NEW_CONN_RATE=500
ANOMALY_WINDOW=10
ANOMALY_AUTOBLOCK=yes
SURICATA_ENABLED=yes
SURICATA_MODE=ips
SURICATA_IFACE=
GAME_ENABLED=yes
GAME_UDP_PPS=3000
GAME_UDP_BURST=8000
GAME_TCP_CONN=80
GAME_PORTS_UDP=27015,27016,27017,27018,7777,7778,19132,19133,25565,25575,2302,2303,9987,30120,64090,2456,2457,28015
GAME_PORTS_TCP=27015,27016,7777,25565,25575,2302,30120,64090,9987,28015
F2B_ENABLED=yes
F2B_SSH_MAXRETRY=5
F2B_SSH_BANTIME=3600
F2B_HTTP_MAXRETRY=100
F2B_HTTP_BANTIME=600
F2B_FINDTIME=60
F2B_RECIDIVE=yes
F2B_RECIDIVE_BANTIME=86400
NGINX_ENABLED=yes
NGINX_REQ_RATE=10r/s
NGINX_BURST=20
NGINX_CONN_PER_IP=50
DISCORD_WEBHOOK=
TELEGRAM_BOT=
TELEGRAM_CHAT=
EMAIL_TO=
REPORT_ENABLED=yes
REPORT_INTERVAL=86400
BAN_TIME=3600
INTERVAL=3
AUTO_BLOCK=yes
AUTOBLOCK_HITS=20
DEFCONF

    chmod 666 "$EAGLE_DIR/data/"*.json 2>/dev/null || true
    chmod 777 "$EAGLE_DIR/data/" 2>/dev/null || true

    python3 -c "
import json, datetime
f='$STATS'
try: d=json.load(open(f))
except: d={}
if 'status' not in d:
    d.update({
      'status':'inactive','version':'6.0',
      'start_time':datetime.datetime.utcnow().isoformat()+'Z',
      'last_update':datetime.datetime.utcnow().isoformat()+'Z',
      'interface':'',
      'mangle':{'drop_invalid':0,'drop_new_not_syn':0,'drop_bad_mss':0,'drop_bad_flags':0,'drop_bogon':0,'total':0},
      'synproxy':{'syn_received':0,'established':0,'cookies_sent':0},
      'l4':{'syn':0,'icmp':0,'xmas':0,'null':0,'frag':0,'scan':0,'udp':0,'ttl':0,'total':0},
      'l7':{'http':0,'https':0,'ssh':0,'total':0},
      'game':{'udp_flood':0,'tcp_flood':0,'rcon':0,'total':0},
      'geoip':{'blocked':0,'countries':[]},
      'suricata':{'alerts':0,'blocked':0},
      'fail2ban':{'banned':0},
      'net':{'bps_in':0,'bps_out':0,'pps_in':0,'pps_out':0,'bytes_in':0,'bytes_out':0,'pkts_in':0,'pkts_out':0},
      'sys':{'cpu':0,'mem':0,'conn':0,'uptime':0},
      'blocked_rules':0
    })
    json.dump(d, open(f,'w'))
" 2>/dev/null || true
    chmod 666 "$STATS" 2>/dev/null || true
}

# ════════════════════════════════════════════════════════════════════
# KATMAN 1: KERNEL HARDENING
# ════════════════════════════════════════════════════════════════════
kernel_harden() {
    log INFO "Kernel parametreleri optimize ediliyor..."

    sysctl -w \
        net.ipv4.tcp_syncookies=1 \
        net.ipv4.tcp_timestamps=1 \
        net.ipv4.tcp_syn_retries=3 \
        net.ipv4.tcp_synack_retries=3 \
        net.ipv4.tcp_max_syn_backlog=65536 \
        net.ipv4.tcp_fin_timeout=10 \
        net.ipv4.tcp_tw_reuse=1 \
        net.ipv4.tcp_abort_on_overflow=1 \
        net.ipv4.tcp_rfc1337=1 \
        net.ipv4.conf.all.rp_filter=1 \
        net.ipv4.conf.default.rp_filter=1 \
        net.ipv4.conf.all.accept_source_route=0 \
        net.ipv4.conf.default.accept_source_route=0 \
        net.ipv4.conf.all.accept_redirects=0 \
        net.ipv4.conf.all.secure_redirects=0 \
        net.ipv4.conf.all.send_redirects=0 \
        net.ipv4.conf.all.log_martians=1 \
        net.ipv4.icmp_echo_ignore_broadcasts=1 \
        net.ipv4.icmp_ignore_bogus_error_responses=1 \
        net.ipv4.icmp_ratelimit=200 \
        net.ipv4.icmp_ratemask=88089 \
        net.core.rmem_max=268435456 \
        net.core.wmem_max=268435456 \
        net.core.rmem_default=16777216 \
        net.core.wmem_default=16777216 \
        net.core.netdev_max_backlog=50000 \
        net.core.somaxconn=65535 \
        net.core.optmem_max=25165824 \
        net.ipv4.tcp_rmem="4096 87380 268435456" \
        net.ipv4.tcp_wmem="4096 65536 268435456" \
        net.ipv4.udp_rmem_min=16384 \
        net.ipv4.udp_wmem_min=16384 \
        net.ipv4.tcp_mtu_probing=1 \
        net.ipv4.tcp_congestion_control=bbr \
        >/dev/null 2>&1 || true

    # conntrack büyüt
    sysctl -w net.nf_conntrack_max=2097152 >/dev/null 2>&1 || true
    echo 2097152 > /proc/sys/net/nf_conntrack_max 2>/dev/null || true
    sysctl -w net.netfilter.nf_conntrack_tcp_loose=0 >/dev/null 2>&1 || true
    sysctl -w net.netfilter.nf_conntrack_tcp_timeout_established=1800 >/dev/null 2>&1 || true
    sysctl -w net.netfilter.nf_conntrack_tcp_timeout_time_wait=10 >/dev/null 2>&1 || true
    sysctl -w net.netfilter.nf_conntrack_tcp_timeout_close_wait=10 >/dev/null 2>&1 || true

    # IPv6
    sysctl -w \
        net.ipv6.conf.all.accept_redirects=0 \
        net.ipv6.conf.all.accept_source_route=0 \
        >/dev/null 2>&1 || true

    # BBR congestion control
    modprobe tcp_bbr 2>/dev/null || true

    log OK "Kernel hardening tamamlandı (BBR + conntrack optimize)"
}

kernel_reset() {
    sysctl -w \
        net.ipv4.tcp_syncookies=1 \
        net.ipv4.conf.all.rp_filter=1 \
        net.ipv4.conf.all.log_martians=0 \
        net.netfilter.nf_conntrack_tcp_loose=1 \
        >/dev/null 2>&1 || true
}

# ════════════════════════════════════════════════════════════════════
# KATMAN 2: MANGLE/PREROUTING — EN ERKEN FİLTRELEME
# Paketler INPUT/FORWARD'a gelmeden DROP edilir
# Filter table'dan çok daha performanslı
# ════════════════════════════════════════════════════════════════════
mangle_apply() {
    [[ "$MANGLE_ENABLED" != "yes" ]] && { log INFO "Mangle devre dışı"; return; }
    log INFO "Mangle/PREROUTING kuralları uygulanıyor..."

    # Temizle
    iptables -t mangle -D PREROUTING -j EG_MANGLE 2>/dev/null
    iptables -t mangle -F EG_MANGLE 2>/dev/null
    iptables -t mangle -X EG_MANGLE 2>/dev/null
    iptables -t mangle -N EG_MANGLE
    iptables -t mangle -I PREROUTING 1 -j EG_MANGLE

    # Whitelist
    while IFS= read -r ip; do
        [[ -z "$ip" || "$ip" == \#* ]] && continue
        [[ ! "$ip" =~ : ]] && \
            iptables -t mangle -A EG_MANGLE -s "$ip" -j RETURN 2>/dev/null
    done < "$WL"

    # 1. Invalid paketler — en başta drop
    iptables -t mangle -A EG_MANGLE \
        -m conntrack --ctstate INVALID -j DROP

    # 2. Yeni bağlantı ama SYN değil (saldırı paketi)
    iptables -t mangle -A EG_MANGLE \
        -p tcp ! --syn -m conntrack --ctstate NEW \
        -j LOG --log-prefix "[EG-MNG-NOSYN] " --log-level 4
    iptables -t mangle -A EG_MANGLE \
        -p tcp ! --syn -m conntrack --ctstate NEW -j DROP

    # 3. Şüpheli MSS değeri (saldırı araçları genelde yanlış MSS)
    if [[ "$L4_MSS_CHECK" == "yes" ]]; then
        iptables -t mangle -A EG_MANGLE \
            -p tcp -m conntrack --ctstate NEW \
            -m tcpmss ! --mss 536:65535 \
            -j LOG --log-prefix "[EG-MNG-MSS] " --log-level 4 2>/dev/null
        iptables -t mangle -A EG_MANGLE \
            -p tcp -m conntrack --ctstate NEW \
            -m tcpmss ! --mss 536:65535 -j DROP 2>/dev/null
    fi

    # 4. TCP Flag kombinasyonu saldırıları — TÜM kombinasyonlar
    # XMAS
    iptables -t mangle -A EG_MANGLE \
        -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG FIN,SYN,RST,PSH,ACK,URG \
        -j LOG --log-prefix "[EG-MNG-XMAS] " --log-level 4
    iptables -t mangle -A EG_MANGLE \
        -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG FIN,SYN,RST,PSH,ACK,URG -j DROP
    # NULL
    iptables -t mangle -A EG_MANGLE \
        -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG NONE \
        -j LOG --log-prefix "[EG-MNG-NULL] " --log-level 4
    iptables -t mangle -A EG_MANGLE \
        -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG NONE -j DROP
    # Geçersiz flag kombinasyonları
    for flags in "FIN,SYN FIN,SYN" "SYN,RST SYN,RST" "FIN,RST FIN,RST" \
                  "FIN,ACK FIN" "ACK,URG URG" "ACK,FIN FIN" \
                  "ACK,PSH PSH" "FIN,PSH,URG FIN,PSH,URG" \
                  "SYN,FIN,PSH,URG SYN,FIN,PSH,URG" \
                  "FIN,SYN,RST,ACK,URG FIN,SYN,RST,ACK,URG"; do
        iptables -t mangle -A EG_MANGLE \
            -p tcp --tcp-flags $flags -j DROP 2>/dev/null
    done

    # 5. Bogon IP'ler — sahte/geçersiz kaynak IP (mangle'da çok hızlı)
    for bogon in \
        "0.0.0.0/8" "10.0.0.0/8" "100.64.0.0/10" "127.0.0.0/8" \
        "169.254.0.0/16" "172.16.0.0/12" "192.0.2.0/24" \
        "192.168.0.0/16" "198.18.0.0/15" "198.51.100.0/24" \
        "203.0.113.0/24" "224.0.0.0/3" "240.0.0.0/5"; do
        iptables -t mangle -A EG_MANGLE -s "$bogon" -j DROP 2>/dev/null
    done

    # 6. TTL anomali tespiti (saldırı araçları düşük TTL kullanır)
    iptables -t mangle -A EG_MANGLE \
        -m ttl --ttl-lt "$L4_TTL_MIN" \
        -j LOG --log-prefix "[EG-MNG-TTL] " --log-level 4 2>/dev/null
    iptables -t mangle -A EG_MANGLE \
        -m ttl --ttl-lt "$L4_TTL_MIN" -j DROP 2>/dev/null

    # 7. Amplification port'larını PREROUTING'da engelle (en verimli)
    for port in 1900 11211 19 17 123 161 389 3389; do
        iptables -t mangle -A EG_MANGLE -p udp --dport $port -j DROP 2>/dev/null
    done

    # 8. Fragmented UDP paketler (çoğu saldırı)
    iptables -t mangle -A EG_MANGLE -p udp -f -j DROP 2>/dev/null

    local cnt; cnt=$(iptables -t mangle -L EG_MANGLE --line-numbers -n 2>/dev/null | grep -c "^[0-9]" || echo 0)
    log MANGLE "mangle/PREROUTING aktif ($cnt kural) — paketler INPUT'a gelmeden filtreleniyor"
}

# ════════════════════════════════════════════════════════════════════
# KATMAN 3: SYNPROXY — SYN FLOOD ULTRA KORUMA
# Kernel seviyesinde TCP proxy — 10x SYN handling kapasitesi
# ════════════════════════════════════════════════════════════════════
synproxy_apply() {
    [[ "$SYNPROXY_ENABLED" != "yes" ]] && { log INFO "SYNPROXY devre dışı"; return; }
    log INFO "SYNPROXY uygulanıyor..."

    # SYNPROXY için SYN paketleri conntrack'ten çıkar (raw table)
    iptables -t raw -D PREROUTING -j EG_SYNPROXY_RAW 2>/dev/null
    iptables -t raw -F EG_SYNPROXY_RAW 2>/dev/null
    iptables -t raw -X EG_SYNPROXY_RAW 2>/dev/null
    iptables -t raw -N EG_SYNPROXY_RAW
    iptables -t raw -I PREROUTING 1 -j EG_SYNPROXY_RAW

    # SYNPROXY INPUT zinciri
    iptables -D INPUT -j EG_SYNPROXY 2>/dev/null
    iptables -F EG_SYNPROXY 2>/dev/null
    iptables -X EG_SYNPROXY 2>/dev/null
    iptables -N EG_SYNPROXY

    # Belirtilen portlar için SYNPROXY uygula
    IFS=',' read -ra SPORTS <<< "$SYNPROXY_PORTS"
    for port in "${SPORTS[@]}"; do
        port=$(echo "$port" | tr -d ' ')
        [[ -z "$port" ]] && continue

        # raw: SYN paketlerini conntrack dışında tut
        iptables -t raw -A EG_SYNPROXY_RAW \
            -p tcp --dport "$port" --syn -j CT --notrack 2>/dev/null

        # SYNPROXY: gerçek bağlantı kontrolü
        iptables -A EG_SYNPROXY \
            -p tcp --dport "$port" \
            -m conntrack --ctstate INVALID,UNTRACKED \
            -j SYNPROXY \
            --sack-perm --timestamp \
            --wscale "$SYNPROXY_WSCALE" \
            --mss "$SYNPROXY_MSS" \
            2>/dev/null
    done

    # SYNPROXY sonrası INVALID paketleri drop et
    iptables -A EG_SYNPROXY -m conntrack --ctstate INVALID -j DROP

    # INPUT'a ekle (mangle'dan sonra, L4'ten önce)
    iptables -I INPUT 1 -j EG_SYNPROXY

    log PROXY "SYNPROXY aktif — portlar: $SYNPROXY_PORTS (MSS:$SYNPROXY_MSS WSCALE:$SYNPROXY_WSCALE)"
    log PROXY "SYN flood kapasitesi ~10x artırıldı"
}

# ════════════════════════════════════════════════════════════════════
# KATMAN 4: IPTABLES — L4/L7/GAME + GEOIP
# ════════════════════════════════════════════════════════════════════
apply_rules() {
    log INFO "iptables kuralları uygulanıyor..."

    # Zincirleri temizle
    for c in EG_ACCEPT EG_L4 EG_L7 EG_GAME EG_GEOIP; do
        iptables -D INPUT   -j "$c" 2>/dev/null
        iptables -D FORWARD -j "$c" 2>/dev/null
        iptables -F "$c" 2>/dev/null
        iptables -X "$c" 2>/dev/null
        iptables -N "$c"
    done
    ip6tables -D INPUT -j EG_L4_6 2>/dev/null
    ip6tables -F EG_L4_6 2>/dev/null; ip6tables -X EG_L4_6 2>/dev/null
    ip6tables -N EG_L4_6 2>/dev/null

    # Sıra: SYNPROXY(1) → ACCEPT(2) → GEOIP(3) → L4(4) → L7(5) → GAME(6)
    iptables -I INPUT 2 -j EG_ACCEPT
    iptables -I INPUT 3 -j EG_GEOIP
    iptables -I INPUT 4 -j EG_L4
    iptables -I INPUT 5 -j EG_L7
    iptables -I INPUT 6 -j EG_GAME
    ip6tables -I INPUT 1 -j EG_L4_6 2>/dev/null

    # ─── EG_ACCEPT ────────────────────────────────────────────────────
    iptables -A EG_ACCEPT -i lo -j ACCEPT
    iptables -A EG_ACCEPT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

    # Whitelist
    while IFS= read -r ip; do
        [[ -z "$ip" || "$ip" == \#* ]] && continue
        [[ "$ip" =~ : ]] \
            && ip6tables -A EG_L4_6 -s "$ip" -j ACCEPT 2>/dev/null \
            || iptables  -A EG_ACCEPT -s "$ip" -j ACCEPT 2>/dev/null
    done < "$WL"

    # SSH — rate limit + geçiş
    iptables -A EG_ACCEPT -p tcp --dport 22 --syn \
        -m hashlimit --hashlimit-name ssh_bf \
        --hashlimit-above "${L7_SSH_RATE}/min" \
        --hashlimit-mode srcip --hashlimit-burst 10 \
        -j LOG --log-prefix "[EG-SSH-BF] " --log-level 4 2>/dev/null
    iptables -A EG_ACCEPT -p tcp --dport 22 --syn \
        -m hashlimit --hashlimit-name ssh_bf \
        --hashlimit-above "${L7_SSH_RATE}/min" \
        --hashlimit-mode srcip --hashlimit-burst 10 -j DROP 2>/dev/null
    iptables -A EG_ACCEPT -p tcp --dport 22  -j ACCEPT
    iptables -A EG_ACCEPT -p tcp --dport 80  -j ACCEPT
    iptables -A EG_ACCEPT -p tcp --dport 443 -j ACCEPT

    # ─── EG_GEOIP ─────────────────────────────────────────────────────
    geoip_apply_rules

    # ─── EG_L4 ────────────────────────────────────────────────────────
    # SYN Flood — global rate
    iptables -A EG_L4 -p tcp --syn \
        -m limit --limit "${L4_SYN_RATE}/s" --limit-burst "$L4_SYN_BURST" -j RETURN
    iptables -A EG_L4 -p tcp --syn \
        -j LOG --log-prefix "[EG-L4-SYN] " --log-level 4
    iptables -A EG_L4 -p tcp --syn -j DROP

    # SYN — IP başına
    iptables -A EG_L4 -p tcp --syn \
        -m hashlimit --hashlimit-name syn_ip \
        --hashlimit-above "${L4_SYN_PER_IP}/sec" \
        --hashlimit-mode srcip \
        --hashlimit-burst $((L4_SYN_PER_IP*3)) -j DROP 2>/dev/null

    # Bağlantı limiti
    iptables -A EG_L4 -p tcp \
        -m connlimit --connlimit-above "$L4_CONN_PER_IP" --connlimit-mask 32 \
        -j LOG --log-prefix "[EG-L4-CLIM] " --log-level 4
    iptables -A EG_L4 -p tcp \
        -m connlimit --connlimit-above "$L4_CONN_PER_IP" --connlimit-mask 32 -j DROP

    # ICMP flood
    iptables -A EG_L4 -p icmp --icmp-type echo-request \
        -m limit --limit "${L4_ICMP_RATE}/s" \
        --limit-burst $((L4_ICMP_RATE*2)) -j RETURN
    iptables -A EG_L4 -p icmp --icmp-type echo-request \
        -j LOG --log-prefix "[EG-L4-ICMP] " --log-level 4
    iptables -A EG_L4 -p icmp --icmp-type echo-request -j DROP
    iptables -A EG_L4 -p icmp -j RETURN

    # Fragmented packets
    iptables -A EG_L4 -f \
        -j LOG --log-prefix "[EG-L4-FRAG] " --log-level 4
    iptables -A EG_L4 -f -j DROP

    # UDP — genel rate (oyun portları EG_GAME'de ayrı)
    iptables -A EG_L4 -p udp \
        -m hashlimit --hashlimit-name udp_general \
        --hashlimit-above "${L4_UDP_PPS}/sec" \
        --hashlimit-mode srcip \
        --hashlimit-burst $((L4_UDP_PPS*3)) \
        -j LOG --log-prefix "[EG-L4-UDP] " --log-level 4 2>/dev/null
    iptables -A EG_L4 -p udp \
        -m hashlimit --hashlimit-name udp_general \
        --hashlimit-above "${L4_UDP_PPS}/sec" \
        --hashlimit-mode srcip \
        --hashlimit-burst $((L4_UDP_PPS*3)) -j DROP 2>/dev/null

    # DNS rate limit
    iptables -A EG_L4 -p udp --dport 53 \
        -m hashlimit --hashlimit-name dns_rl \
        --hashlimit-above "60/sec" --hashlimit-mode srcip \
        --hashlimit-burst 120 -j DROP 2>/dev/null

    # Port scan
    iptables -A EG_L4 -m recent --name EG_SCAN \
        --rcheck --seconds 60 --hitcount 30 \
        -j LOG --log-prefix "[EG-L4-SCAN] " --log-level 4
    iptables -A EG_L4 -m recent --name EG_SCAN \
        --rcheck --seconds 60 --hitcount 30 -j DROP
    iptables -A EG_L4 -m recent --name EG_SCAN --set -j RETURN

    # ─── EG_L7 ────────────────────────────────────────────────────────
    iptables -A EG_L7 -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
    # FTP brute force
    iptables -A EG_L7 -p tcp --dport 21 \
        -m hashlimit --hashlimit-name ftp_bf \
        --hashlimit-above "10/min" --hashlimit-mode srcip \
        --hashlimit-burst 15 -j DROP 2>/dev/null

    # ─── EG_GAME ──────────────────────────────────────────────────────
    if [[ "$GAME_ENABLED" == "yes" ]]; then
        iptables -A EG_GAME -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
        iptables -A EG_GAME -i lo -j RETURN

        IFS=',' read -ra UPORTS <<< "$GAME_PORTS_UDP"
        for port in "${UPORTS[@]}"; do
            port=$(echo "$port" | tr -d ' '); [[ -z "$port" ]] && continue
            iptables -A EG_GAME -p udp --dport "$port" \
                -m hashlimit --hashlimit-name "gu${port}" \
                --hashlimit-above "${GAME_UDP_PPS}/sec" \
                --hashlimit-mode srcip --hashlimit-burst "$GAME_UDP_BURST" \
                -j LOG --log-prefix "[EG-GAME-UDP] " --log-level 4 2>/dev/null
            iptables -A EG_GAME -p udp --dport "$port" \
                -m hashlimit --hashlimit-name "gu${port}" \
                --hashlimit-above "${GAME_UDP_PPS}/sec" \
                --hashlimit-mode srcip --hashlimit-burst "$GAME_UDP_BURST" -j DROP 2>/dev/null
            # Tiny UDP (sahte paket)
            iptables -A EG_GAME -p udp --dport "$port" \
                -m length --length 0:15 -j DROP 2>/dev/null
        done

        IFS=',' read -ra TPORTS <<< "$GAME_PORTS_TCP"
        for port in "${TPORTS[@]}"; do
            port=$(echo "$port" | tr -d ' '); [[ -z "$port" ]] && continue
            iptables -A EG_GAME -p tcp --dport "$port" \
                -m connlimit --connlimit-above "$GAME_TCP_CONN" --connlimit-mask 32 \
                -j LOG --log-prefix "[EG-GAME-TCP] " --log-level 4
            iptables -A EG_GAME -p tcp --dport "$port" \
                -m connlimit --connlimit-above "$GAME_TCP_CONN" --connlimit-mask 32 -j DROP
            iptables -A EG_GAME -p tcp --dport "$port" --syn \
                -m hashlimit --hashlimit-name "gn${port}" \
                --hashlimit-above "8/sec" --hashlimit-mode srcip \
                --hashlimit-burst 20 -j DROP 2>/dev/null
        done

        # RCON brute force
        for rp in 27015 25575; do
            iptables -A EG_GAME -p tcp --dport "$rp" \
                -m hashlimit --hashlimit-name "rc${rp}" \
                --hashlimit-above "5/min" --hashlimit-mode srcip \
                --hashlimit-burst 10 \
                -j LOG --log-prefix "[EG-GAME-RCON] " --log-level 4 2>/dev/null
            iptables -A EG_GAME -p tcp --dport "$rp" \
                -m hashlimit --hashlimit-name "rc${rp}" \
                --hashlimit-above "5/min" --hashlimit-mode srcip \
                --hashlimit-burst 10 -j DROP 2>/dev/null
        done
        log GAME "Game Layer aktif"
    fi

    # IPv6 temel
    ip6tables -A EG_L4_6 -i lo -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -m conntrack --ctstate INVALID -j DROP 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --dport 22  -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --dport 80  -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --dport 443 -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --syn \
        -m limit --limit "${L4_SYN_RATE}/s" --limit-burst "$L4_SYN_BURST" -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --syn -j DROP 2>/dev/null
    ip6tables -A EG_L4_6 -p icmpv6 \
        -m limit --limit 50/s --limit-burst 100 -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -p icmpv6 -j DROP 2>/dev/null

    log OK "iptables aktif — SSH/Web korunuyor"
}

# ════════════════════════════════════════════════════════════════════
# KATMAN 5: GEOIP BLOCKING
# ════════════════════════════════════════════════════════════════════
geoip_apply_rules() {
    [[ "$GEOIP_ENABLED" != "yes" ]] && return
    [[ -z "$GEOIP_BLOCK_COUNTRIES" && -z "$GEOIP_ALLOW_ONLY" ]] && return

    # ipset kurulu mu?
    if ! command -v ipset >/dev/null 2>&1; then
        log WARN "GeoIP: ipset kurulu değil — kuruluyor..."
        DEBIAN_FRONTEND=noninteractive apt-get install -y ipset >/dev/null 2>&1 || {
            log WARN "GeoIP: ipset kurulamadı — devre dışı"
            return
        }
    fi

    log GEO "GeoIP kuralları uygulanıyor..."

    if [[ -n "$GEOIP_BLOCK_COUNTRIES" ]]; then
        for country in $GEOIP_BLOCK_COUNTRIES; do
            country=$(echo "$country" | tr '[:lower:]' '[:upper:]')
            _geoip_fetch_and_block "$country"
        done
    fi

    if [[ -n "$GEOIP_ALLOW_ONLY" ]]; then
        # Sadece belirtilen ülkelere izin ver, geri kalanı block
        log GEO "Whitelist modu: sadece $GEOIP_ALLOW_ONLY izin verilecek"
        ipset create EG_GEOIP_ALLOW hash:net 2>/dev/null || ipset flush EG_GEOIP_ALLOW
        for country in $GEOIP_ALLOW_ONLY; do
            country=$(echo "$country" | tr '[:lower:]' '[:upper:]')
            _geoip_fetch_to_set "$country" "EG_GEOIP_ALLOW"
        done
        # Whitelist'te olmayan her şeyi engelle
        iptables -A EG_GEOIP ! -m set --match-set EG_GEOIP_ALLOW src \
            -j LOG --log-prefix "[EG-GEO-DENY] " --log-level 4
        iptables -A EG_GEOIP ! -m set --match-set EG_GEOIP_ALLOW src -j DROP
    fi
}

_geoip_fetch_and_block() {
    local country="$1"
    local setname="EG_GEO_${country}"
    local url="https://www.iwik.org/ipcountry/${country}.cidr"

    log GEO "$country IP aralıkları indiriliyor..."

    ipset create "$setname" hash:net 2>/dev/null || ipset flush "$setname"

    # IP listesini indir ve ipset'e ekle
    curl -sf --max-time 30 "$url" 2>/dev/null | while read -r cidr; do
        [[ -z "$cidr" || "$cidr" == \#* ]] && continue
        ipset add "$setname" "$cidr" 2>/dev/null || true
    done

    local cnt; cnt=$(ipset list "$setname" 2>/dev/null | grep -c "^[0-9]" || echo 0)
    if [[ "$cnt" -gt 0 ]]; then
        iptables -A EG_GEOIP -m set --match-set "$setname" src \
            -j LOG --log-prefix "[EG-GEO-$country] " --log-level 4
        iptables -A EG_GEOIP -m set --match-set "$setname" src -j DROP
        log GEO "$country: $cnt CIDR blok engellendi"
        echo "$country" >> "$EAGLE_DIR/logs/geoip.log"
    else
        log WARN "GeoIP: $country için veri alınamadı"
    fi
}

_geoip_fetch_to_set() {
    local country="$1" setname="$2"
    local url="https://www.iwik.org/ipcountry/${country}.cidr"
    curl -sf --max-time 30 "$url" 2>/dev/null | while read -r cidr; do
        [[ -z "$cidr" || "$cidr" == \#* ]] && continue
        ipset add "$setname" "$cidr" 2>/dev/null || true
    done
}

geoip_update() {
    log GEO "GeoIP veritabanı güncelleniyor..."
    # Mevcut GeoIP setlerini yenile
    if [[ -n "$GEOIP_BLOCK_COUNTRIES" ]]; then
        for country in $GEOIP_BLOCK_COUNTRIES; do
            country=$(echo "$country" | tr '[:lower:]' '[:upper:]')
            local setname="EG_GEO_${country}"
            ipset flush "$setname" 2>/dev/null || true
            _geoip_fetch_and_block "$country"
        done
    fi
    log GEO "GeoIP güncellemesi tamamlandı"
}

# ════════════════════════════════════════════════════════════════════
# KATMAN 6: SUBURİCA IDS/IPS
# ════════════════════════════════════════════════════════════════════
suricata_setup() {
    [[ "$SURICATA_ENABLED" != "yes" ]] && { log INFO "Suricata devre dışı"; return; }

    command -v suricata >/dev/null 2>&1 || {
        log INFO "Suricata kuruluyor..."
        DEBIAN_FRONTEND=noninteractive apt-get install -y suricata >/dev/null 2>&1 || {
            log WARN "Suricata kurulamadı — devre dışı"
            return
        }
    }

    # Arayüzü tespit et
    [[ -z "$SURICATA_IFACE" ]] && \
        SURICATA_IFACE=$(ip route 2>/dev/null | awk '/default/{print $5;exit}')
    [[ -z "$SURICATA_IFACE" ]] && SURICATA_IFACE=eth0

    # Eagle Guard özel Suricata kuralları
    mkdir -p /etc/suricata/rules
    cat > "$SURICATA_RULES" << 'SRULES'
# Eagle Guard — Suricata Özel Kuralları
# DDoS, Scan, Exploit tespit kuralları

# SYN Flood tespiti
alert tcp any any -> $HOME_NET any (msg:"EG: SYN Flood tespit edildi"; flags:S; threshold:type both,track by_src,count 1000,seconds 1; classtype:denial-of-service; sid:9000001; rev:1;)

# UDP Flood tespiti
alert udp any any -> $HOME_NET any (msg:"EG: UDP Flood tespit edildi"; threshold:type both,track by_src,count 5000,seconds 1; classtype:denial-of-service; sid:9000002; rev:1;)

# ICMP Flood tespiti
alert icmp any any -> $HOME_NET any (msg:"EG: ICMP Flood tespit edildi"; itype:8; threshold:type both,track by_src,count 100,seconds 1; classtype:denial-of-service; sid:9000003; rev:1;)

# HTTP Flood tespiti
alert http any any -> $HOME_NET $HTTP_PORTS (msg:"EG: HTTP Flood tespit edildi"; threshold:type both,track by_src,count 200,seconds 10; classtype:denial-of-service; sid:9000004; rev:1;)

# Port Scan tespiti
alert tcp any any -> $HOME_NET any (msg:"EG: Port Scan tespit edildi"; flags:S; threshold:type threshold,track by_src,count 100,seconds 60; classtype:attempted-recon; sid:9000005; rev:1;)

# SSH Brute Force tespiti
alert tcp any any -> $HOME_NET 22 (msg:"EG: SSH Brute Force tespit edildi"; flags:S; threshold:type both,track by_src,count 10,seconds 60; classtype:attempted-admin; sid:9000006; rev:1;)

# DNS Amplification tespiti
alert udp any 53 -> $HOME_NET any (msg:"EG: DNS Amplification"; dsize:>512; threshold:type both,track by_src,count 10,seconds 1; classtype:denial-of-service; sid:9000007; rev:1;)

# NULL Scan
alert tcp any any -> $HOME_NET any (msg:"EG: NULL Scan"; flags:0; classtype:attempted-recon; sid:9000008; rev:1;)

# XMAS Scan
alert tcp any any -> $HOME_NET any (msg:"EG: XMAS Scan"; flags:SPUAFRG12; classtype:attempted-recon; sid:9000009; rev:1;)

# Slowloris tespiti
alert tcp any any -> $HOME_NET $HTTP_PORTS (msg:"EG: Slowloris saldırısı"; flow:to_server,established; content:"X-a:"; depth:200; threshold:type both,track by_src,count 10,seconds 30; classtype:denial-of-service; sid:9000010; rev:1;)

# HTTP User-Agent scanner
alert http any any -> $HOME_NET $HTTP_PORTS (msg:"EG: Scanner tespit edildi"; http.user_agent; content:"masscan"; nocase; classtype:attempted-recon; sid:9000011; rev:1;)
alert http any any -> $HOME_NET $HTTP_PORTS (msg:"EG: Scanner tespit edildi"; http.user_agent; content:"nikto"; nocase; classtype:attempted-recon; sid:9000012; rev:1;)
alert http any any -> $HOME_NET $HTTP_PORTS (msg:"EG: Scanner tespit edildi"; http.user_agent; content:"sqlmap"; nocase; classtype:web-application-attack; sid:9000013; rev:1;)

# Game sunucu flood
alert udp any any -> $HOME_NET 27015:27018 (msg:"EG: CS2 UDP Flood"; threshold:type both,track by_src,count 3000,seconds 1; classtype:denial-of-service; sid:9000020; rev:1;)
alert udp any any -> $HOME_NET 25565 (msg:"EG: Minecraft UDP Flood"; threshold:type both,track by_src,count 3000,seconds 1; classtype:denial-of-service; sid:9000021; rev:1;)
alert udp any any -> $HOME_NET 30120 (msg:"EG: FiveM UDP Flood"; threshold:type both,track by_src,count 3000,seconds 1; classtype:denial-of-service; sid:9000022; rev:1;)
SRULES

    # Suricata yapılandırması
    local mode_opt
    if [[ "$SURICATA_MODE" == "ips" ]]; then
        mode_opt="nfq"
    else
        mode_opt="af-packet"
    fi

    # Suricata'nın EG kurallarını dahil et
    if ! grep -q "eagle-guard" /etc/suricata/suricata.yaml 2>/dev/null; then
        echo "  - $SURICATA_RULES" >> /etc/suricata/suricata.yaml 2>/dev/null || true
    fi

    # IPS modu için NFQ kural ekle
    if [[ "$SURICATA_MODE" == "ips" ]]; then
        iptables -I INPUT 1 -j NFQUEUE --queue-num 0 2>/dev/null || true
        iptables -I OUTPUT 1 -j NFQUEUE --queue-num 0 2>/dev/null || true
        log IDS "Suricata IPS modu — NFQ aktif"
    fi

    systemctl enable suricata >/dev/null 2>&1 || true
    systemctl restart suricata 2>/dev/null && \
        log IDS "Suricata $SURICATA_MODE modu aktif — ${SURICATA_IFACE}" || \
        log WARN "Suricata başlatılamadı"

    # Suricata alert'lerini izle ve Eagle Guard'a entegre et
    suricata_monitor &
}

suricata_monitor() {
    local slog="/var/log/suricata/fast.log"
    [[ ! -f "$slog" ]] && return

    # Yeni satırları izle ve otomatik ban uygula
    tail -F "$slog" 2>/dev/null | while read -r line; do
        # IP'yi al
        local src_ip; src_ip=$(echo "$line" | grep -oP '\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?=:\d+ ->)' | head -1)
        [[ -z "$src_ip" ]] && continue
        # Denial-of-service alert'lerinde otomatik ban
        if echo "$line" | grep -q "denial-of-service\|DDoS\|Flood"; then
            ip_block "$src_ip" "suricata:dos" IDS
        fi
    done
}

suricata_remove() {
    iptables -D INPUT  -j NFQUEUE 2>/dev/null || true
    iptables -D OUTPUT -j NFQUEUE 2>/dev/null || true
    systemctl stop suricata 2>/dev/null || true
    log INFO "Suricata kaldırıldı"
}

# ════════════════════════════════════════════════════════════════════
# KATMAN 7: FAİL2BAN
# ════════════════════════════════════════════════════════════════════
fail2ban_setup() {
    [[ "$F2B_ENABLED" != "yes" ]] && { log INFO "Fail2ban devre dışı"; return; }
    command -v fail2ban-server >/dev/null 2>&1 || {
        DEBIAN_FRONTEND=noninteractive apt-get install -y fail2ban >/dev/null 2>&1 || {
            log WARN "Fail2ban kurulamadı"; return
        }
    }

    mkdir -p /etc/fail2ban/filter.d

    cat > "$F2B_CONF" << JAILEOF
[DEFAULT]
banaction = iptables-allports

[eagle-guard-ssh]
enabled   = true
port      = ssh
filter    = sshd
logpath   = /var/log/auth.log
            /var/log/secure
maxretry  = ${F2B_SSH_MAXRETRY}
bantime   = ${F2B_SSH_BANTIME}
findtime  = ${F2B_FINDTIME}

[eagle-guard-http]
enabled   = true
port      = http,https
filter    = eagle-guard-http
logpath   = /var/log/nginx/access.log
            /var/log/apache2/access.log
maxretry  = ${F2B_HTTP_MAXRETRY}
bantime   = ${F2B_HTTP_BANTIME}
findtime  = ${F2B_FINDTIME}

[eagle-guard-scan]
enabled   = true
port      = all
filter    = eagle-guard-scan
logpath   = /var/log/kern.log
            /var/log/syslog
maxretry  = 3
bantime   = 7200
findtime  = 60

[eagle-guard-suricata]
enabled   = true
port      = all
filter    = eagle-guard-suricata
logpath   = /var/log/suricata/fast.log
maxretry  = 3
bantime   = 3600
findtime  = 60

$([ "$F2B_RECIDIVE" = "yes" ] && echo "
[recidive]
enabled  = true
filter   = recidive
logpath  = /var/log/fail2ban.log
maxretry = 3
bantime  = ${F2B_RECIDIVE_BANTIME}
findtime = 86400")
JAILEOF

    # HTTP filter
    cat > /etc/fail2ban/filter.d/eagle-guard-http.conf << 'FEOF'
[Definition]
failregex = ^<HOST> .* "(GET|POST|HEAD|PUT|DELETE|OPTIONS) .* HTTP.*" (4\d\d|5\d\d)
ignoreregex =
FEOF

    # Scan filter
    cat > /etc/fail2ban/filter.d/eagle-guard-scan.conf << 'FEOF'
[Definition]
failregex = .*EG-L4-SCAN.*SRC=<HOST>
            .*EG-MNG-XMAS.*SRC=<HOST>
            .*EG-MNG-NULL.*SRC=<HOST>
            .*EG-MNG-NOSYN.*SRC=<HOST>
ignoreregex =
FEOF

    # Suricata filter
    cat > /etc/fail2ban/filter.d/eagle-guard-suricata.conf << 'FEOF'
[Definition]
failregex = \[Classification: denial-of-service\].*<HOST>
            \[Classification: attempted-recon\].*<HOST>
ignoreregex =
FEOF

    systemctl enable fail2ban >/dev/null 2>&1 || true
    systemctl restart fail2ban 2>/dev/null && \
        log F2B "Fail2ban aktif — Recidive: $F2B_RECIDIVE (${F2B_RECIDIVE_BANTIME}s)" || \
        log WARN "Fail2ban başlatılamadı"
}

fail2ban_remove() {
    rm -f "$F2B_CONF"
    rm -f /etc/fail2ban/filter.d/eagle-guard-*.conf
    systemctl reload fail2ban 2>/dev/null || true
    log INFO "Fail2ban konfigürasyonu kaldırıldı"
}

# ════════════════════════════════════════════════════════════════════
# KATMAN 8: NGİNX RATE LİMİTİNG
# ════════════════════════════════════════════════════════════════════
nginx_setup() {
    [[ "$NGINX_ENABLED" != "yes" ]] && { log INFO "Nginx devre dışı"; return; }
    command -v nginx >/dev/null 2>&1 || { log INFO "Nginx kurulu değil — atlanıyor"; return; }

    mkdir -p /etc/nginx/conf.d
    cat > "$NGINX_CONF" << NGXEOF
# Eagle Guard v6.0 — Nginx Rate Limiting
limit_req_zone  \$binary_remote_addr zone=eg_req:10m  rate=${NGINX_REQ_RATE};
limit_conn_zone \$binary_remote_addr zone=eg_conn:10m;

# Scanner UA engelleme
map \$http_user_agent \$block_ua {
    default         0;
    ~*masscan       1; ~*nikto          1; ~*sqlmap        1;
    ~*nmap          1; ~*zgrab          1; ~*dirbuster     1;
    ~*hydra         1; ~*metasploit     1; ~*burpsuite      1;
    ""              1;
}

# Ülke bazlı engelleme (GeoIP2 modülü gerektirir)
# map \$geoip2_data_country_code \$allowed_country {
#     default 0;
#     TR 1; US 1; DE 1;
# }

server {
    listen 80  default_server;
    listen 443 ssl default_server;

    ssl_certificate     /etc/ssl/certs/ssl-cert-snakeoil.pem;
    ssl_certificate_key /etc/ssl/private/ssl-cert-snakeoil.key;

    # Rate limiting
    limit_req  zone=eg_req burst=${NGINX_BURST} nodelay;
    limit_conn zone=eg_conn ${NGINX_CONN_PER_IP};

    # Slowloris koruması
    client_max_body_size   10m;
    client_body_timeout    10s;
    client_header_timeout  10s;
    keepalive_timeout      30s;
    send_timeout           10s;

    # Scanner UA engelle
    if (\$block_ua) { return 444; }

    # Güvenlik header'ları
    add_header X-Frame-Options SAMEORIGIN;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";

    # Real IP log
    log_format eg_detailed '\$remote_addr [\$time_local] "\$request" '
                            '\$status \$body_bytes_sent '
                            'rt=\$request_time ua="\$http_user_agent"';
    access_log /var/log/nginx/eagle-guard.log eg_detailed;

    location / {
        proxy_pass              http://127.0.0.1:8080;
        proxy_set_header        X-Real-IP \$remote_addr;
        proxy_set_header        X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header        Host \$host;
        proxy_connect_timeout   5s;
        proxy_read_timeout      30s;
    }
}
NGXEOF

    nginx -t >/dev/null 2>&1 && {
        systemctl reload nginx 2>/dev/null || true
        log NGX "Nginx rate limit aktif — ${NGINX_REQ_RATE}/IP, conn:${NGINX_CONN_PER_IP}"
    } || {
        log WARN "Nginx config hatası — rate limit atlandı"
        rm -f "$NGINX_CONF"
    }
}

nginx_remove() {
    rm -f "$NGINX_CONF"
    nginx -t >/dev/null 2>&1 && systemctl reload nginx 2>/dev/null || true
    log INFO "Nginx konfigürasyonu kaldırıldı"
}

# ════════════════════════════════════════════════════════════════════
# BİLDİRİM SİSTEMİ
# ════════════════════════════════════════════════════════════════════
send_discord() {
    local title="$1" msg="$2" color="${3:-15158332}"
    [[ -z "$DISCORD_WEBHOOK" ]] && return
    python3 -c "
import json, datetime, urllib.request
payload = json.dumps({
    'username': 'Eagle Guard',
    'embeds': [{
        'title': '🦅 ' + '''$title''',
        'description': '''$msg''',
        'color': $color,
        'footer': {'text': 'Eagle Guard v6.0 • $(hostname)'},
        'timestamp': datetime.datetime.utcnow().isoformat()
    }]
}).encode()
req = urllib.request.Request('$DISCORD_WEBHOOK',
    data=payload,
    headers={'Content-Type': 'application/json'},
    method='POST')
try: urllib.request.urlopen(req, timeout=5)
except: pass
" 2>/dev/null &
}

send_telegram() {
    local title="$1" msg="$2" emoji="${3:-🦅}"
    [[ -z "$TELEGRAM_BOT" || -z "$TELEGRAM_CHAT" ]] && return
    local text="${emoji} *Eagle Guard v6.0*%0A*${title}*%0A${msg}%0A🖥 $(hostname)"
    curl -sf "https://api.telegram.org/bot${TELEGRAM_BOT}/sendMessage" \
        -d "chat_id=${TELEGRAM_CHAT}&text=${text}&parse_mode=Markdown" \
        >/dev/null 2>&1 &
}

send_email() {
    local subject="$1" body="$2"
    [[ -z "$EMAIL_TO" ]] && return
    command -v sendmail >/dev/null 2>&1 || return
    {
        echo "From: Eagle Guard <${EMAIL_FROM}>"
        echo "To: ${EMAIL_TO}"
        echo "Subject: Eagle Guard: ${subject}"
        echo "MIME-Version: 1.0"
        echo "Content-Type: text/html; charset=UTF-8"
        echo ""
        echo "<html><body style='font-family:Arial;background:#0a0f1e;color:#e8f4ff;padding:20px'>"
        echo "<h2 style='color:#00e5ff'>🦅 Eagle Guard v6.0</h2>"
        echo "<h3>${subject}</h3><p>${body}</p>"
        echo "<hr><small>$(hostname) | $(date)</small></body></html>"
    } | sendmail "$EMAIL_TO" 2>/dev/null &
}

notify() {
    local type="$1" title="$2" detail="$3" sev="${4:-medium}"
    python3 - <<PY 2>/dev/null
import json
f="$ALERTS"
try: d=json.load(open(f))
except: d={"alerts":[]}
import datetime
d["alerts"].insert(0,{"type":"$type","title":"$title","detail":"$detail",
  "severity":"$sev","time":datetime.datetime.utcnow().isoformat()+"Z","read":False})
d["alerts"]=d["alerts"][:200]
json.dump(d,open(f,"w"))
PY
    local color emoji
    case "$sev" in
        high)   color=15158332; emoji="🔴" ;;
        medium) color=16776960; emoji="🟡" ;;
        low)    color=65280;    emoji="🟢" ;;
        *)      color=3447003;  emoji="🔵" ;;
    esac
    send_discord "$title" "$detail" "$color"
    send_telegram "$title" "$detail" "$emoji"
    send_email "$title" "<b>$title</b><br>$detail"
}

# ════════════════════════════════════════════════════════════════════
# TRAFİK ANOMALİ ANALİZİ
# ════════════════════════════════════════════════════════════════════
anomaly_detect() {
    local pps_in=$1 bps_in=$2 conn=$3
    [[ "$ANOMALY_ENABLED" != "yes" ]] && return

    # Yeni bağlantı hızını hesapla
    local new_conn; new_conn=$(ss -tn state syn-recv 2>/dev/null | wc -l || echo 0)

    # PPS anomali
    if [[ "$pps_in" -gt "$ANOMALY_PPS_THRESHOLD" ]]; then
        local mbps=$(( bps_in / 1048576 ))
        log ALERT "ANOMALİ: Yüksek PPS $pps_in (eşik: $ANOMALY_PPS_THRESHOLD)"
        log_attack "PPS_FLOOD pps=$pps_in bps=${bps_in} mbps=${mbps}"
        notify "ddos" "⚡ DDoS Saldırısı Tespit!" \
            "PPS: ${pps_in}/s | Bant: ${mbps}MB/s" "high"

        # Anomali yüksekse auto-throttle
        if [[ "$ANOMALY_AUTOBLOCK" == "yes" && "$pps_in" -gt $((ANOMALY_PPS_THRESHOLD*3)) ]]; then
            log ALERT "Kritik DDoS — Dinamik rate limit devreye giriyor"
            # Geçici olarak SYN rate'i düşür
            iptables -t mangle -I EG_MANGLE 1 \
                -p tcp --syn \
                -m limit --limit "50/s" --limit-burst 100 -j RETURN 2>/dev/null
            iptables -t mangle -I EG_MANGLE 2 \
                -p tcp --syn -j DROP 2>/dev/null
            # 60 saniye sonra kaldır
            (sleep 60
             iptables -t mangle -D EG_MANGLE 1 2>/dev/null
             iptables -t mangle -D EG_MANGLE 2 2>/dev/null
             log INFO "Dinamik rate limit kaldırıldı") &
        fi
    fi

    # BPS anomali
    if [[ "$bps_in" -gt "$ANOMALY_BPS_THRESHOLD" ]]; then
        local mbps=$(( bps_in / 1048576 ))
        log ALERT "ANOMALİ: Yüksek bant genişliği ${mbps}MB/s"
        log_attack "BANDWIDTH_FLOOD bps=${bps_in} mbps=${mbps}"
        notify "flood" "📡 Yüksek Bant Genişliği!" "${mbps}MB/s tespit edildi" "high"
    fi

    # Bağlantı anomali
    if [[ "$conn" -gt "$ANOMALY_CONN_THRESHOLD" ]]; then
        log WARN "ANOMALİ: Yüksek bağlantı $conn"
        notify "conn" "🔗 Aşırı Bağlantı" "Aktif: $conn (eşik: $ANOMALY_CONN_THRESHOLD)" "medium"
    fi

    # SYN flood (bağlantı isteği yüksekse)
    if [[ "$new_conn" -gt "$ANOMALY_NEW_CONN_RATE" ]]; then
        log WARN "ANOMALİ: Yüksek SYN-RECV $new_conn"
        log_attack "SYN_FLOOD new_conn=$new_conn"
    fi
}

# ════════════════════════════════════════════════════════════════════
# DETAYLI RAPORLAMA — SALDIRI VEKTÖR ANALİZİ
# ════════════════════════════════════════════════════════════════════
generate_report() {
    log RPT "Detaylı saldırı raporu oluşturuluyor..."

    python3 - <<'PY' 2>/dev/null
import json, datetime, os, re, subprocess

# Stats oku
try: st = json.load(open("/opt/eagle-guard/data/stats.json"))
except: st = {}

# Engellenen IP'ler
try:
    blk = json.load(open("/opt/eagle-guard/data/blocked.json"))
    blocked_list = blk.get("blocked", [])
    today = datetime.date.today().isoformat()
    blocked_today = [b for b in blocked_list if b.get("time","")[:10] == today]
except: blocked_today = []

# Alertler
try:
    alts = json.load(open("/opt/eagle-guard/data/alerts.json"))
    alerts_today = [a for a in alts.get("alerts",[]) if a.get("time","")[:10] == datetime.date.today().isoformat()]
    high_alerts  = [a for a in alerts_today if a.get("severity") == "high"]
except: alerts_today = []; high_alerts = []

# Trafik analizi
try:
    trf = json.load(open("/opt/eagle-guard/data/traffic.json"))
    pts = trf.get("points", [])
    yesterday = (datetime.datetime.utcnow() - datetime.timedelta(hours=24)).isoformat()
    recent = [p for p in pts if p.get("t","") > yesterday]
    max_pps = max((p.get("pps_in",0) for p in recent), default=0)
    avg_pps = int(sum(p.get("pps_in",0) for p in recent) / max(len(recent),1))
    max_bps = max((p.get("bps_in",0) for p in recent), default=0)
except: max_pps = avg_pps = max_bps = 0

# Saldırı vektör analizi (kernel log'dan)
vectors = {}
for logf in ["/var/log/kern.log", "/var/log/syslog"]:
    if not os.path.exists(logf): continue
    try:
        with open(logf) as f:
            for line in f.readlines()[-5000:]:
                for pattern in ["EG-MNG-XMAS", "EG-MNG-NULL", "EG-MNG-NOSYN", "EG-MNG-MSS",
                                 "EG-L4-SYN", "EG-L4-ICMP", "EG-L4-FRAG", "EG-L4-SCAN",
                                 "EG-L4-CLIM", "EG-L4-UDP", "EG-L4-TTL",
                                 "EG-SSH-BF", "EG-GAME-UDP", "EG-GAME-TCP", "EG-GAME-RCON",
                                 "EG-GEO"]:
                    if pattern in line:
                        vectors[pattern] = vectors.get(pattern, 0) + 1
    except: pass

# En çok saldıran IP'ler
top_attackers = sorted(blocked_today, key=lambda x: x.get("hits",0), reverse=True)[:10]

# Rapor oluştur
l4  = st.get("l4", {})
l7  = st.get("l7", {})
gm  = st.get("game", {})
mng = st.get("mangle", {})
sp  = st.get("synproxy", {})

report = {
    "date":              datetime.date.today().isoformat(),
    "generated_at":      datetime.datetime.utcnow().isoformat() + "Z",
    "hostname":          os.uname().nodename,
    "uptime_hours":      round(st.get("sys",{}).get("uptime",0)/3600, 1),
    "summary": {
        "total_blocked":     len(blocked_today),
        "total_alerts":      len(alerts_today),
        "high_severity":     len(high_alerts),
        "unique_attackers":  len(set(b.get("ip") for b in blocked_today)),
        "max_pps":           max_pps,
        "avg_pps":           avg_pps,
        "max_mbps":          round(max_bps/1048576, 2),
    },
    "attack_vectors": {
        "mangle": {
            "xmas_null":     vectors.get("EG-MNG-XMAS",0) + vectors.get("EG-MNG-NULL",0),
            "bad_syn":       vectors.get("EG-MNG-NOSYN",0),
            "bad_mss":       vectors.get("EG-MNG-MSS",0),
            "total":         mng.get("total",0),
        },
        "synproxy": {
            "syn_received":  sp.get("syn_received",0),
            "established":   sp.get("established",0),
        },
        "l4": {
            "syn_flood":     l4.get("syn",0) + vectors.get("EG-L4-SYN",0),
            "icmp_flood":    l4.get("icmp",0),
            "frag_attack":   l4.get("frag",0),
            "port_scan":     l4.get("scan",0) + vectors.get("EG-L4-SCAN",0),
            "udp_flood":     vectors.get("EG-L4-UDP",0),
            "total":         l4.get("total",0),
        },
        "l7": {
            "ssh_brute":     l7.get("ssh",0) + vectors.get("EG-SSH-BF",0),
            "http_flood":    l7.get("http",0),
            "total":         l7.get("total",0),
        },
        "game": {
            "udp_flood":     gm.get("udp_flood",0) + vectors.get("EG-GAME-UDP",0),
            "tcp_flood":     gm.get("tcp_flood",0),
            "rcon_brute":    gm.get("rcon",0) + vectors.get("EG-GAME-RCON",0),
            "total":         gm.get("total",0),
        },
        "geoip": st.get("geoip", {}),
        "suricata": st.get("suricata", {}),
        "fail2ban": st.get("fail2ban", {}),
    },
    "top_attackers": top_attackers,
    "raw_vectors": vectors,
    "timeline": [{"time": p.get("t","")[:19], "pps": p.get("pps_in",0),
                  "mbps": round(p.get("bps_in",0)/1048576,2),
                  "conn": p.get("conn",0)} for p in recent[-48:]],
}

# Rapor DB'ye ekle
try:
    rdb = json.load(open("/opt/eagle-guard/data/report.json"))
except:
    rdb = {"reports": []}
rdb["reports"].insert(0, report)
rdb["reports"] = rdb["reports"][:90]
json.dump(rdb, open("/opt/eagle-guard/data/report.json","w"))

# Konsol özeti
total = report["summary"]["total_blocked"]
av = report["attack_vectors"]
print(f"""
╔══════════════════════════════════════════════════════════╗
║  Eagle Guard v6.0 — Detaylı Saldırı Raporu              ║
╠══════════════════════════════════════════════════════════╣
  📅 Tarih       : {report['date']}
  🖥  Sunucu      : {report['hostname']}
  ⏰ Uptime      : {report['uptime_hours']} saat
  ──────────────────────────────────────────────────────
  🚫 Engellenen  : {total} IP
  🔔 Alert       : {report['summary']['total_alerts']} ({report['summary']['high_severity']} yüksek)
  📦 Max PPS     : {report['summary']['max_pps']:,} pkt/s
  📡 Max Bant    : {report['summary']['max_mbps']} MB/s
  ──────────────────────────────────────────────────────
  SALDIRI VEKTÖRLERİ:
  ⚡ Mangle      : {av['mangle']['total']:,} paket (erken engelleme)
     XMAS/NULL  : {av['mangle']['xmas_null']:,}
     Bad SYN    : {av['mangle']['bad_syn']:,}
  🔒 SYNPROXY    : {av['synproxy']['syn_received']:,} SYN alındı
  🔵 L4 Toplam  : {av['l4']['total']:,}
     SYN Flood  : {av['l4']['syn_flood']:,}
     ICMP Flood : {av['l4']['icmp_flood']:,}
     Port Scan  : {av['l4']['port_scan']:,}
     UDP Flood  : {av['l4']['udp_flood']:,}
  🟡 L7 Toplam  : {av['l7']['total']:,}
     SSH Brute  : {av['l7']['ssh_brute']:,}
  🎮 Game Toplam: {av['game']['total']:,}
     UDP Flood  : {av['game']['udp_flood']:,}
     RCON Brute : {av['game']['rcon_brute']:,}
╚══════════════════════════════════════════════════════════╝
""")
PY
    log RPT "Rapor oluşturuldu → /opt/eagle-guard/data/report.json"
    notify "report" "📊 Güvenlik Raporu" "Günlük rapor hazır — $(hostname)" "low"
}

report_loop() {
    [[ "$REPORT_ENABLED" != "yes" ]] && return
    while true; do
        sleep "$REPORT_INTERVAL"
        load_conf
        generate_report
    done
}

# ── IP Engelle ────────────────────────────────────────────────────────
ip_block() {
    local ip=$1 reason=${2:-manual} layer=${3:-L4}
    [[ -z "$ip" ]] && return 1
    grep -qF "$ip" "$WL" 2>/dev/null && { log WARN "Whitelist: $ip"; return 1; }
    iptables -C EG_L4 -s "$ip" -j DROP 2>/dev/null && return 0
    iptables -I EG_L4 1 -s "$ip" -j DROP
    # Mangle'da da engelle (en hızlı)
    iptables -t mangle -I EG_MANGLE 1 -s "$ip" -j DROP 2>/dev/null
    # Fail2ban'a da ekle
    command -v fail2ban-client >/dev/null 2>&1 && \
        fail2ban-client set eagle-guard-scan banip "$ip" 2>/dev/null || true
    log ALERT "[$layer] ENGELLENDİ: $ip — $reason"
    log_attack "BLOCKED ip=$ip reason=$reason layer=$layer"
    _jblock "$ip" "$reason" "$layer" add
    notify "block" "🚫 IP Engellendi [$layer]" "IP: $ip | Sebep: $reason" "high"
    [[ "$BAN_TIME" -gt 0 ]] && (sleep "$BAN_TIME"; ip_unblock "$ip" ban_expired) &
}

ip_unblock() {
    local ip=$1 reason=${2:-manual}
    iptables -D EG_L4    -s "$ip" -j DROP 2>/dev/null
    iptables -D EG_ACCEPT -s "$ip" -j ACCEPT 2>/dev/null
    iptables -t mangle -D EG_MANGLE -s "$ip" -j DROP 2>/dev/null
    command -v fail2ban-client >/dev/null 2>&1 && \
        fail2ban-client set eagle-guard-scan unbanip "$ip" 2>/dev/null || true
    log INFO "Engel kaldırıldı: $ip ($reason)"
    _jblock "$ip" "$reason" "" remove
}

_jblock() {
    python3 - <<PY 2>/dev/null
import json
f="$BLOCKED"
try: d=json.load(open(f))
except: d={"blocked":[]}
ts=__import__('datetime').datetime.utcnow().isoformat()+'Z'
if "$4"=="add":
    x=next((i for i in d["blocked"] if i["ip"]=="$1"),None)
    if x: x["hits"]=x.get("hits",1)+1; x["last"]="$ts"
    else: d["blocked"].insert(0,{"ip":"$1","reason":"$2","layer":"$3","time":ts,"hits":1})
    d["blocked"]=d["blocked"][:500]
else: d["blocked"]=[i for i in d["blocked"] if i["ip"]!="$1"]
json.dump(d,open(f,"w"))
PY
}

# ── İstatistik topla ──────────────────────────────────────────────────
collect() {
    local iface; iface=$(ip route 2>/dev/null | awk '/default/{print $5;exit}')
    [[ -z "$iface" ]] && iface=eth0
    local rx_b tx_b rx_p tx_p
    rx_b=$(cat /sys/class/net/$iface/statistics/rx_bytes   2>/dev/null||echo 0)
    tx_b=$(cat /sys/class/net/$iface/statistics/tx_bytes   2>/dev/null||echo 0)
    rx_p=$(cat /sys/class/net/$iface/statistics/rx_packets 2>/dev/null||echo 0)
    tx_p=$(cat /sys/class/net/$iface/statistics/tx_packets 2>/dev/null||echo 0)

    local prx ptx prxp ptxp
    prx=$(python3  -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('bytes_in',0))"  2>/dev/null||echo 0)
    ptx=$(python3  -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('bytes_out',0))" 2>/dev/null||echo 0)
    prxp=$(python3 -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('pkts_in',0))"  2>/dev/null||echo 0)
    ptxp=$(python3 -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('pkts_out',0))" 2>/dev/null||echo 0)

    local bps_in bps_out pps_in pps_out
    bps_in=$(( (rx_b-prx)/INTERVAL )); bps_out=$(( (tx_b-ptx)/INTERVAL ))
    pps_in=$(( (rx_p-prxp)/INTERVAL )); pps_out=$(( (tx_p-ptxp)/INTERVAL ))
    for v in bps_in bps_out pps_in pps_out; do [[ ${!v} -lt 0 ]] && eval "$v=0"; done

    local cpu; cpu=$(awk '{printf "%.1f",$1*100/'"$(nproc 2>/dev/null||echo 1)"'}' /proc/loadavg 2>/dev/null||echo 0)
    local mem; mem=$(free 2>/dev/null|awk '/Mem:/{printf "%.1f",$3/$2*100}'||echo 0)
    local conn; conn=$(ss -tn state established 2>/dev/null|wc -l||echo 0)
    local uptime=0
    uptime=$(python3 -c "
import json,datetime
try:
    d=json.load(open('$STATS'))
    st=d.get('start_time','')
    if st:
        from datetime import timezone
        s=datetime.datetime.fromisoformat(st.replace('Z','+00:00'))
        print(int((datetime.datetime.now(timezone.utc)-s).total_seconds()))
    else: print(0)
except: print(0)" 2>/dev/null||echo 0)

    # Anomali tespiti
    anomaly_detect "$pps_in" "$bps_in" "$conn"

    # iptables sayaçları
    local l4_syn l4_icmp l4_xmas l4_null l4_frag l4_scan l4_udp
    local l7_http l7_https l7_ssh
    local g_udp g_tcp g_rcon
    local mng_total sp_data blk f2b_cnt
    l4_syn=$(iptables  -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-SYN/{s+=$1}END{print s+0}')
    l4_icmp=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-ICMP/{s+=$1}END{print s+0}')
    l4_xmas=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-XMAS/{s+=$1}END{print s+0}')
    l4_null=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-NULL/{s+=$1}END{print s+0}')
    l4_frag=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-FRAG/{s+=$1}END{print s+0}')
    l4_scan=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-SCAN/{s+=$1}END{print s+0}')
    l4_udp=$(iptables  -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-UDP/{s+=$1}END{print s+0}')
    l7_http=$(iptables -L EG_L7   -nvx 2>/dev/null|awk '/EG-L7-HTTP/{s+=$1}END{print s+0}')
    l7_https=$(iptables -L EG_L7  -nvx 2>/dev/null|awk '/EG-L7-HTTPS/{s+=$1}END{print s+0}')
    l7_ssh=$(iptables  -L EG_ACCEPT -nvx 2>/dev/null|awk '/EG-SSH/{s+=$1}END{print s+0}')
    g_udp=$(iptables   -L EG_GAME -nvx 2>/dev/null|awk '/EG-GAME-UDP/{s+=$1}END{print s+0}')
    g_tcp=$(iptables   -L EG_GAME -nvx 2>/dev/null|awk '/EG-GAME-TCP/{s+=$1}END{print s+0}')
    g_rcon=$(iptables  -L EG_GAME -nvx 2>/dev/null|awk '/EG-GAME-RCON/{s+=$1}END{print s+0}')
    mng_total=$(iptables -t mangle -L EG_MANGLE -nvx 2>/dev/null|awk 'NR>2{s+=$1}END{print s+0}')
    blk=$(iptables     -L EG_L4   -n   2>/dev/null|grep -c "^DROP"||echo 0)
    f2b_cnt=$(fail2ban-client status 2>/dev/null|\
        grep -oP 'Currently banned:\s*\K\d+'|awk '{s+=$1}END{print s+0}'||echo 0)
    sp_data=$(cat /proc/net/stat/synproxy 2>/dev/null|tail -1||echo "0 0 0 0 0 0")

    # Kernel log'dan autoblock
    if [[ "$AUTO_BLOCK" == "yes" ]]; then
        for logf in /var/log/kern.log /var/log/syslog; do
            [[ -r "$logf" ]] || continue
            grep "EG-" "$logf" 2>/dev/null|tail -500|\
                grep -oP 'SRC=\K[\d.]+' |sort|uniq -c|sort -rn|\
                while read -r cnt ip; do
                    [[ "$cnt" -ge "$AUTOBLOCK_HITS" ]] && \
                        ip_block "$ip" "auto:${cnt}hits" L4
                done
        done
    fi

    local ts; ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    python3 - <<PY 2>/dev/null
import json
f="$TRAFFIC"
try: d=json.load(open(f))
except: d={"points":[]}
d["points"].append({
    "t":"$ts","unix":$(date +%s),
    "bps_in":$bps_in,"bps_out":$bps_out,"pps_in":$pps_in,"pps_out":$pps_out,
    "bytes_in":$rx_b,"bytes_out":$tx_b,"conn":$conn,"cpu":$cpu
})
d["points"]=d["points"][-240:]
json.dump(d,open(f,"w"))
PY
    python3 - <<PY 2>/dev/null
import json
f="$STATS"
try: d=json.load(open(f))
except: d={}
d.update({
  "status":"active","last_update":"$ts","interface":"$iface",
  "net":{"bps_in":$bps_in,"bps_out":$bps_out,"pps_in":$pps_in,"pps_out":$pps_out,
         "bytes_in":$rx_b,"bytes_out":$tx_b,"pkts_in":$rx_p,"pkts_out":$tx_p,
         "rx_mb":round($rx_b/1048576,2),"tx_mb":round($tx_b/1048576,2)},
  "mangle":{"total":$mng_total},
  "l4":{"syn":$l4_syn,"icmp":$l4_icmp,"xmas":$l4_xmas,
        "null":$l4_null,"frag":$l4_frag,"scan":$l4_scan,"udp":$l4_udp,
        "total":$l4_syn+$l4_icmp+$l4_xmas+$l4_null+$l4_frag},
  "l7":{"http":$l7_http,"https":$l7_https,"ssh":$l7_ssh,
        "total":$l7_http+$l7_https+$l7_ssh},
  "game":{"udp_flood":$g_udp,"tcp_flood":$g_tcp,"rcon":$g_rcon,
          "total":$g_udp+$g_tcp+$g_rcon},
  "fail2ban":{"banned":$f2b_cnt},
  "sys":{"cpu":$cpu,"mem":$mem,"conn":$conn,"uptime":$uptime},
  "blocked_rules":$blk
})
json.dump(d,open(f,"w"))
PY
}

# ── Kuralları kaldır ──────────────────────────────────────────────────
rules_remove() {
    log INFO "Tüm kurallar kaldırılıyor..."
    # mangle
    iptables -t mangle -D PREROUTING -j EG_MANGLE 2>/dev/null
    iptables -t mangle -F EG_MANGLE 2>/dev/null
    iptables -t mangle -X EG_MANGLE 2>/dev/null
    # raw (SYNPROXY)
    iptables -t raw -D PREROUTING -j EG_SYNPROXY_RAW 2>/dev/null
    iptables -t raw -F EG_SYNPROXY_RAW 2>/dev/null
    iptables -t raw -X EG_SYNPROXY_RAW 2>/dev/null
    # Input zincirleri
    for c in EG_SYNPROXY EG_ACCEPT EG_GEOIP EG_L4 EG_L7 EG_GAME; do
        iptables -D INPUT   -j "$c" 2>/dev/null
        iptables -D FORWARD -j "$c" 2>/dev/null
        iptables -F "$c" 2>/dev/null
        iptables -X "$c" 2>/dev/null
    done
    # ipset'leri temizle
    ipset list -n 2>/dev/null | grep "^EG_" | while read -r s; do
        ipset flush "$s" 2>/dev/null; ipset destroy "$s" 2>/dev/null
    done
    # NFQ (Suricata IPS)
    iptables -D INPUT  -j NFQUEUE 2>/dev/null
    iptables -D OUTPUT -j NFQUEUE 2>/dev/null
    # IPv6
    ip6tables -D INPUT -j EG_L4_6 2>/dev/null
    ip6tables -F EG_L4_6 2>/dev/null; ip6tables -X EG_L4_6 2>/dev/null
    log OK "Tüm kurallar kaldırıldı"
}

# ── TUI ───────────────────────────────────────────────────────────────
tui() {
    while true; do
        clear
        local iface; iface=$(ip route 2>/dev/null|awk '/default/{print $5;exit}')
        local blk; blk=$(iptables -L EG_L4 -n 2>/dev/null|grep -c "^DROP"||echo 0)
        local mblk; mblk=$(iptables -t mangle -L EG_MANGLE -n 2>/dev/null|grep -c "^DROP"||echo 0)
        local conn; conn=$(ss -tn state established 2>/dev/null|wc -l)
        local cpu; cpu=$(awk '{printf "%.0f%%",$1*100/'"$(nproc 2>/dev/null||echo 1)"'}' /proc/loadavg)
        local mem; mem=$(free 2>/dev/null|awk '/Mem:/{printf "%.0f%%",$3/$2*100}')
        local bps; bps=$(python3 -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('bps_in',0))" 2>/dev/null||echo 0)
        local pps; pps=$(python3 -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('pps_in',0))" 2>/dev/null||echo 0)
        local f2b; f2b=$(python3 -c "import json;d=json.load(open('$STATS'));print(d.get('fail2ban',{}).get('banned',0))" 2>/dev/null||echo 0)
        # SYNPROXY istatistikleri
        local sp_syn sp_est
        sp_syn=$(awk '{print $1}' /proc/net/stat/synproxy 2>/dev/null|tail -1||echo 0)
        sp_est=$(awk '{print $3}' /proc/net/stat/synproxy 2>/dev/null|tail -1||echo 0)
        echo -e "${W}"
        echo "  ╔══════════════════════════════════════════════════════════════════════╗"
        echo "  ║  🦅  EAGLE GUARD v6.0  —  Enterprise DDoS Protection Engine         ║"
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        printf "  ║  %-36s  %-33s║\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$(hostname) — ${iface:-eth0}"
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        printf "  ║  ${G}AKTİF${N}  mangle:${Y}%-4s${N} ipt:${R}%-4s${N} f2b:${Y}%-4s${N} conn:${C}%-5s${N} cpu:${Y}%-5s${N} ram:${Y}%-5s${N}║\n" \
            "$mblk" "$blk" "$f2b" "$conn" "$cpu" "$mem"
        printf "  ║  IN: $(echo $bps|awk '{printf "%.2f MB/s",$1/1048576}')  PPS: $pps  SYNPROXY: SYN=$sp_syn EST=$sp_est%-18s║\n" ""
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        echo -e "  ║  ${C}[MNG]${N} mangle/PREROUTING ✓  TTL ✓  MSS ✓  BadFlags ✓  Bogon ✓      ║"
        echo -e "  ║  ${G}[SYP]${N} SYNPROXY ✓  (10x SYN kapasite)                              ║"
        echo -e "  ║  ${C}[L4]${N}  SYN ✓  ICMP ✓  FRAG ✓  UDP ✓  Scan ✓  ConnLimit ✓          ║"
        echo -e "  ║  ${Y}[GEO]${N} GeoIP: $([ "$GEOIP_ENABLED" = "yes" ] && echo "AKTİF ($GEOIP_BLOCK_COUNTRIES)" || echo "Devre Dışı")                               ║"
        echo -e "  ║  ${R}[IDS]${N} Suricata: $([ "$SURICATA_ENABLED" = "yes" ] && echo "$SURICATA_MODE modu" || echo "Devre Dışı")   [F2B] Fail2ban ✓              ║"
        echo -e "  ║  ${G}[GM]${N}  UDP Flood ✓  TCP ✓  RCON ✓  TinyUDP ✓                       ║"
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        echo "  ║  Web: http://$(hostname -I 2>/dev/null|awk '{print $1}')/eagle-guard/  [Q] Çıkış          ║"
        echo -e "  ╚══════════════════════════════════════════════════════════════════════╝${N}"
        read -t 4 -n 1 k 2>/dev/null
        [[ "$k" == "q" || "$k" == "Q" ]] && break
    done
}

# ── Help ──────────────────────────────────────────────────────────────
show_help() {
    echo -e "${C}Eagle Guard v6.0 — Enterprise DDoS Koruma Sistemi${N}"
    echo ""
    echo "KOMUTLAR:"
    echo "  eagle-guard start             Tüm korumaları başlat"
    echo "  eagle-guard stop              Tüm korumaları durdur"
    echo "  eagle-guard restart           Yeniden başlat"
    echo "  eagle-guard status            TUI durum ekranı"
    echo "  eagle-guard stats             JSON istatistik"
    echo "  eagle-guard block <IP>        IP engelle"
    echo "  eagle-guard unblock <IP>      IP engelini kaldır"
    echo "  eagle-guard report            Detaylı saldırı raporu"
    echo "  eagle-guard test-notify       Bildirim testi"
    echo "  eagle-guard geoip-update      GeoIP veritabanını güncelle"
    echo "  eagle-guard rules-mangle      Mangle kuralları"
    echo "  eagle-guard rules-l4          L4 kuralları"
    echo "  eagle-guard rules-l7          L7 kuralları"
    echo "  eagle-guard rules-game        Game kuralları"
    echo "  eagle-guard rules-accept      ACCEPT kuralları"
    echo "  eagle-guard synproxy-stats    SYNPROXY istatistikleri"
    echo "  eagle-guard fail2ban-status   Fail2ban durumu"
    echo "  eagle-guard logs [N]          Son N log"
    echo "  eagle-guard attack-log        Saldırı logları"
    echo "  eagle-guard game-on/off       Game koruması aç/kapat"
    echo "  eagle-guard help              Bu ekran"
    echo ""
    echo "KONFİGÜRASYON: /opt/eagle-guard/config/eagle.conf"
    echo "  Önemli ayarlar:"
    echo "  GEOIP_ENABLED=yes"
    echo "  GEOIP_BLOCK_COUNTRIES=\"CN RU KP\""
    echo "  SYNPROXY_ENABLED=yes"
    echo "  SURICATA_ENABLED=yes"
    echo "  SURICATA_MODE=ips  (veya ids)"
    echo "  DISCORD_WEBHOOK=https://discord.com/api/webhooks/..."
    echo "  TELEGRAM_BOT=token"
    echo "  TELEGRAM_CHAT=chat_id"
}

# ── Ana komutlar ──────────────────────────────────────────────────────
case "${1:-help}" in
    start)
        [[ -f "$PID" ]] && kill -0 "$(cat $PID)" 2>/dev/null && \
            { echo -e "${Y}Zaten çalışıyor (PID: $(cat $PID))${N}"; exit 0; }
        load_conf; setup
        kernel_harden
        mangle_apply
        synproxy_apply
        apply_rules
        fail2ban_setup
        nginx_setup
        suricata_setup
        echo $$ > "$PID"
        python3 -c "
import json,datetime
f='$STATS'
try: d=json.load(open(f))
except: d={}
d['status']='active'
d['start_time']=datetime.datetime.utcnow().isoformat()+'Z'
json.dump(d,open(f,'w'))" 2>/dev/null || true
        log OK "Eagle Guard v6.0 başlatıldı (PID:$$)"
        notify "system" "🦅 Eagle Guard v6.0 Başlatıldı" \
            "mangle+SYNPROXY+L4+L7+Game+Suricata+GeoIP+Fail2ban aktif" "low"
        report_loop &
        while true; do load_conf; collect; sleep "$INTERVAL"; done
        ;;
    stop)
        load_conf; setup
        rules_remove; kernel_reset
        fail2ban_remove; nginx_remove; suricata_remove
        python3 -c "
import json
try:
    d=json.load(open('$STATS')); d['status']='inactive'
    json.dump(d,open('$STATS','w'))
except: pass" 2>/dev/null || true
        notify "system" "Eagle Guard Durduruldu" "Koruma devre dışı" "medium"
        kill "$(cat $PID 2>/dev/null)" 2>/dev/null || true
        rm -f "$PID"
        log OK "Eagle Guard durduruldu"
        ;;
    restart)   "$0" stop; sleep 2; exec "$0" start ;;
    status)    load_conf; setup; tui ;;
    block)
        [[ -z "$2" ]] && { show_help; exit 1; }
        load_conf; setup; ip_block "$2" "${3:-cli}" "${4:-L4}" ;;
    unblock)
        [[ -z "$2" ]] && { show_help; exit 1; }
        load_conf; setup; ip_unblock "$2" cli ;;
    stats)     python3 -m json.tool "$STATS" 2>/dev/null ;;
    report)    load_conf; setup; generate_report ;;
    test-notify)
        load_conf; setup
        notify "system" "🧪 Test Bildirimi" \
            "Eagle Guard v6.0 bildirim testi — $(date)" "low"
        echo "Tüm kanallara gönderildi (ayarlıysa)"
        ;;
    geoip-update)   load_conf; setup; geoip_update ;;
    rules-mangle)   iptables -t mangle -L EG_MANGLE -nvx 2>/dev/null ;;
    rules-l4)       iptables -L EG_L4     -nvx 2>/dev/null ;;
    rules-l7)       iptables -L EG_L7     -nvx 2>/dev/null ;;
    rules-game)     iptables -L EG_GAME   -nvx 2>/dev/null ;;
    rules-accept)   iptables -L EG_ACCEPT -nvx 2>/dev/null ;;
    synproxy-stats)
        echo "=== SYNPROXY İstatistikleri ==="
        cat /proc/net/stat/synproxy 2>/dev/null || echo "SYNPROXY verisi yok"
        ;;
    fail2ban-status)
        command -v fail2ban-client >/dev/null 2>&1 && \
            fail2ban-client status || echo "Fail2ban kurulu değil"
        ;;
    logs)       tail -"${2:-100}" "$LOG" 2>/dev/null ;;
    attack-log) tail -"${2:-100}" "$LOG_ATTACK" 2>/dev/null ;;
    game-on)
        load_conf; setup
        iptables -D INPUT -j EG_GAME 2>/dev/null
        iptables -F EG_GAME 2>/dev/null; iptables -X EG_GAME 2>/dev/null
        iptables -N EG_GAME; iptables -I INPUT 6 -j EG_GAME
        GAME_ENABLED=yes; [[ -f "$CONF" ]] && source "$CONF" 2>/dev/null || true
        iptables -A EG_GAME -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
        IFS=',' read -ra UPORTS <<< "$GAME_PORTS_UDP"
        for port in "${UPORTS[@]}"; do
            port=$(echo "$port"|tr -d ' '); [[ -z "$port" ]] && continue
            iptables -A EG_GAME -p udp --dport "$port" \
                -m hashlimit --hashlimit-name "gu${port}" \
                --hashlimit-above "${GAME_UDP_PPS}/sec" \
                --hashlimit-mode srcip --hashlimit-burst "$GAME_UDP_BURST" -j DROP 2>/dev/null
        done
        log OK "Game koruması açıldı"
        ;;
    game-off)
        iptables -D INPUT -j EG_GAME 2>/dev/null
        iptables -F EG_GAME 2>/dev/null; iptables -X EG_GAME 2>/dev/null
        log OK "Game koruması kapatıldı"
        ;;
    help|--help|-h) show_help ;;
    *) echo "Bilinmeyen: $1"; show_help ;;
esac
