#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════════╗
# ║  EAGLE GUARD v5.0 — L4 / L7 / GAME DDoS Protection                  ║
# ║  SSH ve Web kesintisi YOK — Sadece saldırılar engellenir            ║
# ╚══════════════════════════════════════════════════════════════════════╝
EAGLE_DIR="/opt/eagle-guard"
LOG="$EAGLE_DIR/logs/eagle.log"
STATS="$EAGLE_DIR/data/stats.json"
BLOCKED="$EAGLE_DIR/data/blocked.json"
ALERTS="$EAGLE_DIR/data/alerts.json"
TRAFFIC="$EAGLE_DIR/data/traffic.json"
CONF="$EAGLE_DIR/config/eagle.conf"
WL="$EAGLE_DIR/config/whitelist.txt"
PID="/var/run/eagle-guard.pid"
R='\033[0;31m' G='\033[0;32m' Y='\033[1;33m' C='\033[0;36m' W='\033[1;37m' N='\033[0m'

# ── Config ────────────────────────────────────────────────────────────
load_conf() {
    # Layer 4 limitleri
    L4_SYN_RATE=200          # SYN paket/s (global)
    L4_SYN_BURST=1000
    L4_ICMP_RATE=100         # ICMP echo/s
    # IP başına limitler
    L4_SYN_PER_IP=30         # IP başına SYN/10s
    L4_CONN_PER_IP=300       # IP başına max bağlantı
    L4_NEW_CONN_RATE=20      # IP başına yeni bağlantı/saniye
    # Layer 7
    L7_HTTP_CONN=100         # IP başına HTTP bağlantı
    L7_HTTP_RATE=80          # IP başına HTTP istek/s
    L7_SSH_RATE=6            # IP başına SSH deneme/dakika
    # Game
    GAME_ENABLED=yes
    GAME_UDP_PPS=3000        # IP başına oyun UDP/s
    GAME_UDP_BURST=8000
    GAME_TCP_CONN=80
    GAME_PORTS_UDP="27015,27016,27017,27018,7777,7778,19132,19133,25565,25575,2302,2303,9987,30120,64090,2456,2457,28015"
    GAME_PORTS_TCP="27015,27016,7777,25565,25575,2302,30120,64090,9987,28015"
    # Alert
    ALERT_PPS=15000
    ALERT_BPS=209715200
    ALERT_CONN=8000
    # Genel
    BAN_TIME=3600
    INTERVAL=3
    AUTO_BLOCK=yes
    AUTOBLOCK_HITS=20
    WEBHOOK=""
    EMAIL=""
    TG_BOT=""
    TG_CHAT=""
    [[ -f "$CONF" ]] && source "$CONF"
}

# ── Log ───────────────────────────────────────────────────────────────
log() {
    local l=$1; shift
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$l] $*" >> "$LOG"
    case $l in
        ALERT) echo -e "${R}[ALERT]${N} $*" ;;
        OK)    echo -e "${G}[OK]${N}    $*" ;;
        INFO)  echo -e "${C}[INFO]${N}  $*" ;;
        WARN)  echo -e "${Y}[WARN]${N}  $*" ;;
        GAME)  echo -e "${C}[GAME]${N}  $*" ;;
    esac
}

# ── Init ──────────────────────────────────────────────────────────────
setup() {
    mkdir -p "$EAGLE_DIR"/{logs,data,config}
    [[ ! -f "$WL" ]]      && printf "127.0.0.1\n::1\n" > "$WL"
    [[ ! -f "$BLOCKED" ]] && echo '{"blocked":[]}' > "$BLOCKED"
    [[ ! -f "$ALERTS" ]]  && echo '{"alerts":[]}' > "$ALERTS"
    [[ ! -f "$TRAFFIC" ]] && echo '{"points":[]}' > "$TRAFFIC"
    python3 -c "
import json,datetime
d={
  'status':'inactive','version':'5.0',
  'start_time':datetime.datetime.utcnow().isoformat()+'Z',
  'last_update':datetime.datetime.utcnow().isoformat()+'Z',
  'interface':'',
  'l4':{'syn':0,'icmp':0,'xmas':0,'null':0,'frag':0,'bogon':0,'total':0},
  'l7':{'http':0,'https':0,'ssh':0,'total':0},
  'game':{'udp_flood':0,'tcp_flood':0,'query_flood':0,'total':0},
  'net':{'bps_in':0,'bps_out':0,'pps_in':0,'pps_out':0,
         'bytes_in':0,'bytes_out':0,'pkts_in':0,'pkts_out':0},
  'sys':{'cpu':0,'mem':0,'conn':0,'uptime':0},
  'blocked_rules':0
}
open('$STATS','w').write(json.dumps(d,indent=2))" 2>/dev/null
}

# ── Kernel hardening ──────────────────────────────────────────────────
kernel_harden() {
    log INFO "Kernel parametreleri uygulanıyor..."
    # TCP SYN koruması
    sysctl -w net.ipv4.tcp_syncookies=1              >/dev/null 2>&1
    sysctl -w net.ipv4.tcp_syn_retries=3             >/dev/null 2>&1
    sysctl -w net.ipv4.tcp_synack_retries=3          >/dev/null 2>&1
    sysctl -w net.ipv4.tcp_max_syn_backlog=32768     >/dev/null 2>&1
    sysctl -w net.ipv4.tcp_fin_timeout=15            >/dev/null 2>&1
    sysctl -w net.ipv4.tcp_keepalive_time=300        >/dev/null 2>&1
    sysctl -w net.ipv4.tcp_tw_reuse=1                >/dev/null 2>&1
    # IP Spoofing koruması
    sysctl -w net.ipv4.conf.all.rp_filter=1          >/dev/null 2>&1
    sysctl -w net.ipv4.conf.default.rp_filter=1      >/dev/null 2>&1
    sysctl -w net.ipv4.conf.all.accept_source_route=0 >/dev/null 2>&1
    sysctl -w net.ipv4.conf.all.accept_redirects=0   >/dev/null 2>&1
    sysctl -w net.ipv4.conf.all.send_redirects=0     >/dev/null 2>&1
    sysctl -w net.ipv4.conf.all.log_martians=1       >/dev/null 2>&1
    # ICMP koruması
    sysctl -w net.ipv4.icmp_echo_ignore_broadcasts=1 >/dev/null 2>&1
    sysctl -w net.ipv4.icmp_ignore_bogus_error_responses=1 >/dev/null 2>&1
    # Buffer
    sysctl -w net.core.rmem_max=134217728            >/dev/null 2>&1
    sysctl -w net.core.wmem_max=134217728            >/dev/null 2>&1
    sysctl -w net.core.netdev_max_backlog=10000      >/dev/null 2>&1
    sysctl -w net.core.somaxconn=65535               >/dev/null 2>&1
    # conntrack tablosu büyüt
    sysctl -w net.nf_conntrack_max=1048576           >/dev/null 2>&1 || true
    log OK "Kernel hardening tamamlandı"
}

kernel_reset() {
    sysctl -w net.ipv4.tcp_syncookies=1 >/dev/null 2>&1
    sysctl -w net.ipv4.conf.all.rp_filter=1 >/dev/null 2>&1
}

# ════════════════════════════════════════════════════════════════════
# LAYER 4 — TEMEL KURALLAR
# ÖNEMLI: ÖNCE İZİN VER, SONRA ENGELLE
# ════════════════════════════════════════════════════════════════════
l4_apply() {
    log INFO "Layer 4 kuralları uygulanıyor..."

    # Zincirleri temizle / oluştur
    for c in EG_L4 EG_L7 EG_GAME; do
        iptables -D INPUT   -j "$c" 2>/dev/null
        iptables -D FORWARD -j "$c" 2>/dev/null
        iptables -F "$c" 2>/dev/null
        iptables -X "$c" 2>/dev/null
        iptables -N "$c"
    done
    # IPv6
    ip6tables -D INPUT -j EG_L4_6 2>/dev/null
    ip6tables -F EG_L4_6 2>/dev/null
    ip6tables -X EG_L4_6 2>/dev/null
    ip6tables -N EG_L4_6 2>/dev/null

    # Zincirleri INPUT'a bağla (sıra önemli)
    iptables -I INPUT 1 -j EG_L4
    iptables -I INPUT 2 -j EG_L7
    iptables -I INPUT 3 -j EG_GAME
    ip6tables -I INPUT 1 -j EG_L4_6 2>/dev/null

    # ═══════════════════════════════════════════════════
    # EG_L4 — ÖNCE HER ZAMAN İZİN VERİLECEKLER
    # ═══════════════════════════════════════════════════

    # 1. Loopback her zaman izin
    iptables -A EG_L4 -i lo -j RETURN

    # 2. Mevcut/ilişkili bağlantılar HER ZAMAN geçer (SSH, Web, vb.)
    iptables -A EG_L4 -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN

    # 3. Geçersiz paketleri drop et
    iptables -A EG_L4 -m conntrack --ctstate INVALID -j DROP

    # 4. Whitelist IP'leri her zaman geçer
    while IFS= read -r ip; do
        [[ -z "$ip" || "$ip" == \#* ]] && continue
        [[ "$ip" =~ : ]] \
            && ip6tables -A EG_L4_6 -s "$ip" -j RETURN 2>/dev/null \
            || iptables  -A EG_L4   -s "$ip" -j RETURN 2>/dev/null
    done < "$WL"

    # 5. Kritik yönetim portları her zaman izin (SSH, ICMP ping)
    # SSH — rate limit ile brute force engelle ama kesme
    iptables -A EG_L4 -p tcp --dport 22 --syn \
        -m hashlimit --hashlimit-name ssh_protect \
        --hashlimit-above "${L7_SSH_RATE}/min" \
        --hashlimit-mode srcip --hashlimit-burst 10 \
        -j LOG --log-prefix "[EG-SSH-BF] " --log-level 4 2>/dev/null
    iptables -A EG_L4 -p tcp --dport 22 --syn \
        -m hashlimit --hashlimit-name ssh_protect \
        --hashlimit-above "${L7_SSH_RATE}/min" \
        --hashlimit-mode srcip --hashlimit-burst 10 -j DROP 2>/dev/null
    # SSH meşru bağlantı — geçir
    iptables -A EG_L4 -p tcp --dport 22 -j RETURN

    # Web portları — geçir (L7 zincirinde rate limit yapılacak)
    iptables -A EG_L4 -p tcp --dport 80  -j RETURN
    iptables -A EG_L4 -p tcp --dport 443 -j RETURN

    # ─────────────────────────────────────────────────
    # TCP FLAG SALDIRI TESPİTİ
    # ─────────────────────────────────────────────────
    # XMAS — Tüm flagler set
    iptables -A EG_L4 -p tcp --tcp-flags ALL ALL \
        -j LOG --log-prefix "[EG-L4-XMAS] " --log-level 4
    iptables -A EG_L4 -p tcp --tcp-flags ALL ALL -j DROP
    # NULL — Hiç flag yok
    iptables -A EG_L4 -p tcp --tcp-flags ALL NONE \
        -j LOG --log-prefix "[EG-L4-NULL] " --log-level 4
    iptables -A EG_L4 -p tcp --tcp-flags ALL NONE -j DROP
    # SYN+FIN geçersiz kombinasyon
    iptables -A EG_L4 -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP
    # SYN+RST geçersiz kombinasyon
    iptables -A EG_L4 -p tcp --tcp-flags SYN,RST SYN,RST -j DROP

    # ─────────────────────────────────────────────────
    # SYN FLOOD — GLOBAL RATE LIMIT
    # ─────────────────────────────────────────────────
    # Önce izin ver (normal trafik geçer)
    iptables -A EG_L4 -p tcp --syn \
        -m limit --limit "${L4_SYN_RATE}/s" --limit-burst "$L4_SYN_BURST" -j RETURN
    # Limiti aşanları log ve drop
    iptables -A EG_L4 -p tcp --syn \
        -j LOG --log-prefix "[EG-L4-SYN] " --log-level 4
    iptables -A EG_L4 -p tcp --syn -j DROP

    # ─────────────────────────────────────────────────
    # IP BAŞINA SYN RATE (hashlimit)
    # ─────────────────────────────────────────────────
    iptables -A EG_L4 -p tcp --syn \
        -m hashlimit --hashlimit-name syn_per_ip \
        --hashlimit-above "${L4_SYN_PER_IP}/sec" \
        --hashlimit-mode srcip --hashlimit-burst $((L4_SYN_PER_IP*3)) \
        -j LOG --log-prefix "[EG-L4-SYN-IP] " --log-level 4 2>/dev/null
    iptables -A EG_L4 -p tcp --syn \
        -m hashlimit --hashlimit-name syn_per_ip \
        --hashlimit-above "${L4_SYN_PER_IP}/sec" \
        --hashlimit-mode srcip --hashlimit-burst $((L4_SYN_PER_IP*3)) -j DROP 2>/dev/null

    # ─────────────────────────────────────────────────
    # IP BAŞINA BAĞLANTI SAYISI LIMITI
    # ─────────────────────────────────────────────────
    iptables -A EG_L4 -p tcp \
        -m connlimit --connlimit-above "$L4_CONN_PER_IP" --connlimit-mask 32 \
        -j LOG --log-prefix "[EG-L4-CONNLIM] " --log-level 4
    iptables -A EG_L4 -p tcp \
        -m connlimit --connlimit-above "$L4_CONN_PER_IP" --connlimit-mask 32 -j DROP

    # ─────────────────────────────────────────────────
    # ICMP FLOOD
    # ─────────────────────────────────────────────────
    iptables -A EG_L4 -p icmp --icmp-type echo-request \
        -m limit --limit "${L4_ICMP_RATE}/s" --limit-burst $((L4_ICMP_RATE*2)) -j RETURN
    iptables -A EG_L4 -p icmp --icmp-type echo-request \
        -j LOG --log-prefix "[EG-L4-ICMP] " --log-level 4
    iptables -A EG_L4 -p icmp --icmp-type echo-request -j DROP
    # Diğer ICMP tiplerini geçir (traceroute, unreachable vb.)
    iptables -A EG_L4 -p icmp -j RETURN

    # ─────────────────────────────────────────────────
    # FRAGMENTED PACKETS
    # ─────────────────────────────────────────────────
    iptables -A EG_L4 -f \
        -j LOG --log-prefix "[EG-L4-FRAG] " --log-level 4
    iptables -A EG_L4 -f -j DROP

    # ─────────────────────────────────────────────────
    # BOGON IP FİLTRESİ (sahte/geçersiz kaynak IP)
    # ─────────────────────────────────────────────────
    for bogon in \
        "0.0.0.0/8" "100.64.0.0/10" "169.254.0.0/16" \
        "192.0.2.0/24" "198.51.100.0/24" "203.0.113.0/24" \
        "224.0.0.0/4" "240.0.0.0/4"; do
        iptables -A EG_L4 -s "$bogon" -j DROP 2>/dev/null
    done

    # ─────────────────────────────────────────────────
    # UDP AMPLIFICATION SALDIRI ENGELLEMESİ
    # Sadece amplification vektörleri — genel UDP'yi KAPATMA
    # ─────────────────────────────────────────────────
    # SSDP amplification — tamamen engelle
    iptables -A EG_L4 -p udp --dport 1900 -j DROP
    # Memcached amplification — tamamen engelle
    iptables -A EG_L4 -p udp --dport 11211 -j DROP
    # CharGEN amplification
    iptables -A EG_L4 -p udp --dport 19 -j DROP
    # QOTD amplification
    iptables -A EG_L4 -p udp --dport 17 -j DROP
    # DNS — rate limit (amplification koruması)
    iptables -A EG_L4 -p udp --dport 53 \
        -m hashlimit --hashlimit-name dns_protect \
        --hashlimit-above "50/sec" \
        --hashlimit-mode srcip --hashlimit-burst 100 \
        -j LOG --log-prefix "[EG-L4-DNS] " --log-level 4 2>/dev/null
    iptables -A EG_L4 -p udp --dport 53 \
        -m hashlimit --hashlimit-name dns_protect \
        --hashlimit-above "50/sec" \
        --hashlimit-mode srcip --hashlimit-burst 100 -j DROP 2>/dev/null
    # NTP — rate limit
    iptables -A EG_L4 -p udp --dport 123 \
        -m hashlimit --hashlimit-name ntp_protect \
        --hashlimit-above "20/sec" \
        --hashlimit-mode srcip --hashlimit-burst 50 -j DROP 2>/dev/null

    # ─────────────────────────────────────────────────
    # PORT SCAN TESPİTİ
    # ─────────────────────────────────────────────────
    iptables -A EG_L4 -m recent --name EG_SCAN \
        --rcheck --seconds 60 --hitcount 30 \
        -j LOG --log-prefix "[EG-L4-SCAN] " --log-level 4
    iptables -A EG_L4 -m recent --name EG_SCAN \
        --rcheck --seconds 60 --hitcount 30 -j DROP
    iptables -A EG_L4 -m recent --name EG_SCAN --set -j RETURN

    # IPv6 temel koruma
    ip6tables -A EG_L4_6 -i lo -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -m conntrack --ctstate INVALID -j DROP 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --dport 22  -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --dport 80  -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --dport 443 -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --syn \
        -m limit --limit "${L4_SYN_RATE}/s" --limit-burst "$L4_SYN_BURST" -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --syn -j DROP 2>/dev/null
    ip6tables -A EG_L4_6 -p icmpv6 \
        -m limit --limit 50/s --limit-burst 100 -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -p icmpv6 -j DROP 2>/dev/null

    local cnt; cnt=$(iptables -L EG_L4 --line-numbers -n 2>/dev/null | grep -c "^[0-9]")
    log OK "Layer 4 aktif ($cnt kural) — SSH/Web korunuyor"
}

# ════════════════════════════════════════════════════════════════════
# LAYER 7 — APPLICATION KORUMASI
# ════════════════════════════════════════════════════════════════════
l7_apply() {
    log INFO "Layer 7 kuralları uygulanıyor..."

    # EG_L7 zinciri zaten oluşturuldu (l4_apply içinde)

    # Whitelist geçişi
    while IFS= read -r ip; do
        [[ -z "$ip" || "$ip" == \#* ]] && continue
        [[ ! "$ip" =~ : ]] && iptables -A EG_L7 -s "$ip" -j RETURN 2>/dev/null
    done < "$WL"

    # Mevcut bağlantılar geçer
    iptables -A EG_L7 -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN

    # ─────────────────────────────────────────────────
    # HTTP FLOOD KORUMASI
    # ─────────────────────────────────────────────────
    # IP başına bağlantı limiti
    iptables -A EG_L7 -p tcp --dport 80 \
        -m connlimit --connlimit-above "$L7_HTTP_CONN" --connlimit-mask 32 \
        -j LOG --log-prefix "[EG-L7-HTTP-CONN] " --log-level 4
    iptables -A EG_L7 -p tcp --dport 80 \
        -m connlimit --connlimit-above "$L7_HTTP_CONN" --connlimit-mask 32 -j DROP

    # IP başına istek hızı (hashlimit)
    iptables -A EG_L7 -p tcp --dport 80 \
        -m hashlimit --hashlimit-name http_rate \
        --hashlimit-above "${L7_HTTP_RATE}/sec" \
        --hashlimit-mode srcip --hashlimit-burst $((L7_HTTP_RATE*3)) \
        -j LOG --log-prefix "[EG-L7-HTTP-RATE] " --log-level 4 2>/dev/null
    iptables -A EG_L7 -p tcp --dport 80 \
        -m hashlimit --hashlimit-name http_rate \
        --hashlimit-above "${L7_HTTP_RATE}/sec" \
        --hashlimit-mode srcip --hashlimit-burst $((L7_HTTP_RATE*3)) -j DROP 2>/dev/null

    # ─────────────────────────────────────────────────
    # HTTPS FLOOD
    # ─────────────────────────────────────────────────
    iptables -A EG_L7 -p tcp --dport 443 \
        -m connlimit --connlimit-above "$L7_HTTP_CONN" --connlimit-mask 32 \
        -j LOG --log-prefix "[EG-L7-HTTPS-CONN] " --log-level 4
    iptables -A EG_L7 -p tcp --dport 443 \
        -m connlimit --connlimit-above "$L7_HTTP_CONN" --connlimit-mask 32 -j DROP

    iptables -A EG_L7 -p tcp --dport 443 \
        -m hashlimit --hashlimit-name https_rate \
        --hashlimit-above "${L7_HTTP_RATE}/sec" \
        --hashlimit-mode srcip --hashlimit-burst $((L7_HTTP_RATE*3)) -j DROP 2>/dev/null

    # ─────────────────────────────────────────────────
    # FTP BRUTE FORCE
    # ─────────────────────────────────────────────────
    iptables -A EG_L7 -p tcp --dport 21 --syn \
        -m hashlimit --hashlimit-name ftp_protect \
        --hashlimit-above "10/min" \
        --hashlimit-mode srcip --hashlimit-burst 15 \
        -j LOG --log-prefix "[EG-L7-FTP] " --log-level 4 2>/dev/null
    iptables -A EG_L7 -p tcp --dport 21 --syn \
        -m hashlimit --hashlimit-name ftp_protect \
        --hashlimit-above "10/min" \
        --hashlimit-mode srcip --hashlimit-burst 15 -j DROP 2>/dev/null

    local cnt; cnt=$(iptables -L EG_L7 --line-numbers -n 2>/dev/null | grep -c "^[0-9]")
    log OK "Layer 7 aktif ($cnt kural)"
}

# ════════════════════════════════════════════════════════════════════
# GAME LAYER — OYUN SUNUCUSU KORUMASI
# ════════════════════════════════════════════════════════════════════
game_apply() {
    [[ "$GAME_ENABLED" != "yes" ]] && { log INFO "Game koruması devre dışı"; return; }
    log INFO "Game Layer uygulanıyor..."

    # EG_GAME zinciri zaten oluşturuldu

    # Whitelist geçişi
    while IFS= read -r ip; do
        [[ -z "$ip" || "$ip" == \#* ]] && continue
        [[ ! "$ip" =~ : ]] && iptables -A EG_GAME -s "$ip" -j RETURN 2>/dev/null
    done < "$WL"

    # Mevcut bağlantılar geçer
    iptables -A EG_GAME -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
    iptables -A EG_GAME -i lo -j RETURN

    # ─────────────────────────────────────────────────
    # OYUN UDP PORTLARI — IP BAŞINA RATE LIMIT
    # ─────────────────────────────────────────────────
    IFS=',' read -ra UPORTS <<< "$GAME_PORTS_UDP"
    for port in "${UPORTS[@]}"; do
        port=$(echo "$port" | tr -d ' ')
        [[ -z "$port" ]] && continue

        # IP başına UDP hız limiti
        iptables -A EG_GAME -p udp --dport "$port" \
            -m hashlimit --hashlimit-name "gudp_${port}" \
            --hashlimit-above "${GAME_UDP_PPS}/sec" \
            --hashlimit-mode srcip \
            --hashlimit-burst "$GAME_UDP_BURST" \
            -j LOG --log-prefix "[EG-GAME-UDP] " --log-level 4 2>/dev/null
        iptables -A EG_GAME -p udp --dport "$port" \
            -m hashlimit --hashlimit-name "gudp_${port}" \
            --hashlimit-above "${GAME_UDP_PPS}/sec" \
            --hashlimit-mode srcip \
            --hashlimit-burst "$GAME_UDP_BURST" -j DROP 2>/dev/null

        # Çok küçük UDP (<16 byte) — sahte paket
        iptables -A EG_GAME -p udp --dport "$port" \
            -m length --length 0:15 -j DROP 2>/dev/null

        # Çok büyük UDP (>1450 byte) — amplification
        iptables -A EG_GAME -p udp --dport "$port" \
            -m length --length 1451:65535 \
            -m hashlimit --hashlimit-name "gbig_${port}" \
            --hashlimit-above "5/sec" \
            --hashlimit-mode srcip --hashlimit-burst 10 -j DROP 2>/dev/null
    done

    # ─────────────────────────────────────────────────
    # OYUN TCP PORTLARI — BAĞLANTI LİMİTİ
    # ─────────────────────────────────────────────────
    IFS=',' read -ra TPORTS <<< "$GAME_PORTS_TCP"
    for port in "${TPORTS[@]}"; do
        port=$(echo "$port" | tr -d ' ')
        [[ -z "$port" ]] && continue

        # IP başına TCP bağlantı sayısı
        iptables -A EG_GAME -p tcp --dport "$port" \
            -m connlimit --connlimit-above "$GAME_TCP_CONN" --connlimit-mask 32 \
            -j LOG --log-prefix "[EG-GAME-TCP] " --log-level 4
        iptables -A EG_GAME -p tcp --dport "$port" \
            -m connlimit --connlimit-above "$GAME_TCP_CONN" --connlimit-mask 32 -j DROP

        # Yeni bağlantı hız limiti (fake connect flood)
        iptables -A EG_GAME -p tcp --dport "$port" --syn \
            -m hashlimit --hashlimit-name "gnew_${port}" \
            --hashlimit-above "8/sec" \
            --hashlimit-mode srcip --hashlimit-burst 20 -j DROP 2>/dev/null
    done

    # ─────────────────────────────────────────────────
    # RCON BRUTE FORCE (CS2/Minecraft)
    # ─────────────────────────────────────────────────
    for rcon_port in 27015 25575; do
        iptables -A EG_GAME -p tcp --dport "$rcon_port" \
            -m hashlimit --hashlimit-name "rcon_${rcon_port}" \
            --hashlimit-above "5/min" \
            --hashlimit-mode srcip --hashlimit-burst 10 \
            -j LOG --log-prefix "[EG-GAME-RCON] " --log-level 4 2>/dev/null
        iptables -A EG_GAME -p tcp --dport "$rcon_port" \
            -m hashlimit --hashlimit-name "rcon_${rcon_port}" \
            --hashlimit-above "5/min" \
            --hashlimit-mode srcip --hashlimit-burst 10 -j DROP 2>/dev/null
    done

    local cnt; cnt=$(iptables -L EG_GAME --line-numbers -n 2>/dev/null | grep -c "^[0-9]")
    log GAME "Game Layer aktif ($cnt kural)"
    log GAME "UDP portlar: $GAME_PORTS_UDP"
}

# ── Tüm kuralları kaldır ──────────────────────────────────────────────
rules_remove() {
    log INFO "Tüm EagleGuard kuralları kaldırılıyor..."
    for c in EG_L4 EG_L7 EG_GAME; do
        iptables -D INPUT   -j "$c" 2>/dev/null
        iptables -D FORWARD -j "$c" 2>/dev/null
        iptables -F "$c" 2>/dev/null
        iptables -X "$c" 2>/dev/null
    done
    ip6tables -D INPUT -j EG_L4_6 2>/dev/null
    ip6tables -F EG_L4_6 2>/dev/null
    ip6tables -X EG_L4_6 2>/dev/null
    log OK "Tüm kurallar kaldırıldı"
}

# ── IP Engelle ────────────────────────────────────────────────────────
ip_block() {
    local ip=$1 reason=${2:-manual} layer=${3:-L4}
    [[ -z "$ip" ]] && return 1
    grep -qF "$ip" "$WL" 2>/dev/null && { log WARN "Whitelist'te: $ip"; return 1; }
    iptables -C EG_L4 -s "$ip" -j DROP 2>/dev/null && return 0
    iptables -I EG_L4 1 -s "$ip" -j DROP
    log ALERT "[$layer] ENGELLENDİ: $ip — $reason"
    _jblock "$ip" "$reason" "$layer" add
    alert_push block "IP Engellendi [$layer]" "$ip — $reason" high
    [[ "$BAN_TIME" -gt 0 ]] && (sleep "$BAN_TIME"; ip_unblock "$ip" ban_expired) &
}

ip_unblock() {
    local ip=$1 reason=${2:-manual}
    iptables -D EG_L4 -s "$ip" -j DROP 2>/dev/null
    log INFO "Engel kaldırıldı: $ip ($reason)"
    _jblock "$ip" "$reason" "" remove
}

_jblock() {
    python3 - <<PY 2>/dev/null
import json
f="$BLOCKED"
try: d=json.load(open(f))
except: d={"blocked":[]}
ts=__import__('datetime').datetime.utcnow().isoformat()+'Z'
if "$4"=="add":
    x=next((i for i in d["blocked"] if i["ip"]=="$1"),None)
    if x: x["hits"]=x.get("hits",1)+1; x["last"]="$ts"
    else: d["blocked"].insert(0,{"ip":"$1","reason":"$2","layer":"$3","time":ts,"hits":1})
    d["blocked"]=d["blocked"][:500]
else: d["blocked"]=[i for i in d["blocked"] if i["ip"]!="$1"]
json.dump(d,open(f,"w"))
PY
}

# ── Alert / Bildirim ──────────────────────────────────────────────────
alert_push() {
    local t=$1 title=$2 detail=$3 sev=${4:-medium}
    local ts; ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    python3 - <<PY 2>/dev/null
import json
f="$ALERTS"
try: d=json.load(open(f))
except: d={"alerts":[]}
d["alerts"].insert(0,{"type":"$t","title":"$title","detail":"$detail",
  "severity":"$sev","time":"$ts","read":False})
d["alerts"]=d["alerts"][:200]
json.dump(d,open(f,"w"))
PY
    [[ -n "$WEBHOOK" ]] && {
        local icon="🔴"
        [[ "$sev" == "medium" ]] && icon="🟡"
        [[ "$sev" == "low"    ]] && icon="🟢"
        curl -sf -X POST "$WEBHOOK" \
            -H "Content-Type: application/json" \
            -d "{\"text\":\"$icon *Eagle Guard* — *$title*\\n$detail\"}" \
            >/dev/null 2>&1 &
    }
    [[ -n "$TG_BOT" && -n "$TG_CHAT" ]] && \
        curl -sf "https://api.telegram.org/bot${TG_BOT}/sendMessage" \
            -d "chat_id=$TG_CHAT&text=🦅 Eagle Guard%0A$title%0A$detail" \
            >/dev/null 2>&1 &
    [[ -n "$EMAIL" ]] && command -v mail >/dev/null 2>&1 && \
        echo "$detail" | mail -s "🦅 Eagle Guard: $title" "$EMAIL" &
}

# ── İstatistik topla ──────────────────────────────────────────────────
collect() {
    local iface; iface=$(ip route 2>/dev/null | awk '/default/{print $5;exit}')
    [[ -z "$iface" ]] && iface=eth0

    local rx_b tx_b rx_p tx_p
    rx_b=$(cat /sys/class/net/$iface/statistics/rx_bytes   2>/dev/null || echo 0)
    tx_b=$(cat /sys/class/net/$iface/statistics/tx_bytes   2>/dev/null || echo 0)
    rx_p=$(cat /sys/class/net/$iface/statistics/rx_packets 2>/dev/null || echo 0)
    tx_p=$(cat /sys/class/net/$iface/statistics/tx_packets 2>/dev/null || echo 0)

    # Delta hesapla
    local prx ptx prxp ptxp
    prx=$(python3  -c "import json;d=json.load(open('$STATS'));print(d['net'].get('bytes_in',0))"  2>/dev/null || echo 0)
    ptx=$(python3  -c "import json;d=json.load(open('$STATS'));print(d['net'].get('bytes_out',0))" 2>/dev/null || echo 0)
    prxp=$(python3 -c "import json;d=json.load(open('$STATS'));print(d['net'].get('pkts_in',0))"  2>/dev/null || echo 0)
    ptxp=$(python3 -c "import json;d=json.load(open('$STATS'));print(d['net'].get('pkts_out',0))" 2>/dev/null || echo 0)

    local bps_in bps_out pps_in pps_out
    bps_in=$(( (rx_b-prx)/INTERVAL ))
    bps_out=$(( (tx_b-ptx)/INTERVAL ))
    pps_in=$(( (rx_p-prxp)/INTERVAL ))
    pps_out=$(( (tx_p-ptxp)/INTERVAL ))
    [[ $bps_in  -lt 0 ]] && bps_in=0
    [[ $bps_out -lt 0 ]] && bps_out=0
    [[ $pps_in  -lt 0 ]] && pps_in=0
    [[ $pps_out -lt 0 ]] && pps_out=0

    # Sistem metrikleri
    local cpu; cpu=$(awk '{printf "%.1f",$1*100/'"$(nproc 2>/dev/null||echo 1)"'}' /proc/loadavg 2>/dev/null || echo 0)
    local mem; mem=$(free 2>/dev/null | awk '/Mem:/{printf "%.1f",$3/$2*100}' || echo 0)
    local conn; conn=$(ss -tn state established 2>/dev/null | wc -l || echo 0)

    # Uptime
    local uptime=0
    uptime=$(python3 -c "
import json,datetime
try:
    d=json.load(open('$STATS'))
    st=d.get('start_time','')
    if st:
        from datetime import timezone
        s=datetime.datetime.fromisoformat(st.replace('Z','+00:00'))
        print(int((datetime.datetime.now(timezone.utc)-s).total_seconds()))
    else: print(0)
except: print(0)" 2>/dev/null || echo 0)

    # iptables sayaçları
    local l4_syn l4_icmp l4_xmas l4_null l4_frag l4_scan
    local l7_http l7_https l7_ssh
    local g_udp g_tcp g_rcon
    local blk

    l4_syn=$(iptables  -L EG_L4   -nvx 2>/dev/null | awk '/EG-L4-SYN/{s+=$1}END{print s+0}')
    l4_icmp=$(iptables -L EG_L4   -nvx 2>/dev/null | awk '/EG-L4-ICMP/{s+=$1}END{print s+0}')
    l4_xmas=$(iptables -L EG_L4   -nvx 2>/dev/null | awk '/EG-L4-XMAS/{s+=$1}END{print s+0}')
    l4_null=$(iptables -L EG_L4   -nvx 2>/dev/null | awk '/EG-L4-NULL/{s+=$1}END{print s+0}')
    l4_frag=$(iptables -L EG_L4   -nvx 2>/dev/null | awk '/EG-L4-FRAG/{s+=$1}END{print s+0}')
    l4_scan=$(iptables -L EG_L4   -nvx 2>/dev/null | awk '/EG-L4-SCAN/{s+=$1}END{print s+0}')
    l7_http=$(iptables -L EG_L7   -nvx 2>/dev/null | awk '/EG-L7-HTTP/{s+=$1}END{print s+0}')
    l7_https=$(iptables -L EG_L7  -nvx 2>/dev/null | awk '/EG-L7-HTTPS/{s+=$1}END{print s+0}')
    l7_ssh=$(iptables  -L EG_L4   -nvx 2>/dev/null | awk '/EG-SSH/{s+=$1}END{print s+0}')
    g_udp=$(iptables   -L EG_GAME -nvx 2>/dev/null | awk '/EG-GAME-UDP/{s+=$1}END{print s+0}')
    g_tcp=$(iptables   -L EG_GAME -nvx 2>/dev/null | awk '/EG-GAME-TCP/{s+=$1}END{print s+0}')
    g_rcon=$(iptables  -L EG_GAME -nvx 2>/dev/null | awk '/EG-GAME-RCON/{s+=$1}END{print s+0}')
    blk=$(iptables     -L EG_L4   -n   2>/dev/null | grep -c "^DROP" || echo 0)

    # Anomali tespiti
    if [[ "$AUTO_BLOCK" == "yes" ]]; then
        [[ "$pps_in" -gt "$ALERT_PPS" ]] && {
            log ALERT "DDoS! PPS: $pps_in (eşik: $ALERT_PPS)"
            alert_push ddos "⚠️ DDoS Saldırısı!" "PPS: ${pps_in}/s" high
        }
        [[ "$bps_in" -gt "$ALERT_BPS" ]] && {
            local mbps=$(( bps_in/1048576 ))
            log ALERT "Yüksek BW: ${mbps} MB/s"
            alert_push flood "⚠️ Yüksek Bant Genişliği!" "${mbps} MB/s" high
        }
        # Kernel log'dan otomatik IP engelleme
        for logf in /var/log/kern.log /var/log/syslog; do
            [[ -r "$logf" ]] || continue
            grep "EG-" "$logf" 2>/dev/null | tail -500 | \
                grep -oP 'SRC=\K[\d.]+' | sort | uniq -c | sort -rn | \
                while read -r cnt ip; do
                    [[ "$cnt" -ge "$AUTOBLOCK_HITS" ]] && \
                        ip_block "$ip" "auto:${cnt}hits" L4
                done
        done
    fi

    local ts; ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    # Trafik geçmişi
    python3 - <<PY 2>/dev/null
import json
f="$TRAFFIC"
try: d=json.load(open(f))
except: d={"points":[]}
d["points"].append({
    "t":"$ts","unix":$(date +%s),
    "bps_in":$bps_in,"bps_out":$bps_out,
    "pps_in":$pps_in,"pps_out":$pps_out,
    "bytes_in":$rx_b,"bytes_out":$tx_b,
    "conn":$conn,"cpu":$cpu
})
d["points"]=d["points"][-240:]
json.dump(d,open(f,"w"))
PY

    # Stats güncelle
    python3 - <<PY 2>/dev/null
import json
f="$STATS"
try: d=json.load(open(f))
except: d={}
d.update({
    "status":"active","last_update":"$ts","interface":"$iface",
    "net":{
        "bps_in":$bps_in,"bps_out":$bps_out,
        "pps_in":$pps_in,"pps_out":$pps_out,
        "bytes_in":$rx_b,"bytes_out":$tx_b,
        "pkts_in":$rx_p,"pkts_out":$tx_p,
        "rx_mb":round($rx_b/1048576,2),"tx_mb":round($tx_b/1048576,2)
    },
    "l4":{
        "syn":$l4_syn,"icmp":$l4_icmp,"xmas":$l4_xmas,
        "null":$l4_null,"frag":$l4_frag,"scan":$l4_scan,
        "total":$l4_syn+$l4_icmp+$l4_xmas+$l4_null+$l4_frag
    },
    "l7":{
        "http":$l7_http,"https":$l7_https,"ssh":$l7_ssh,
        "total":$l7_http+$l7_https+$l7_ssh
    },
    "game":{
        "udp_flood":$g_udp,"tcp_flood":$g_tcp,"rcon":$g_rcon,
        "total":$g_udp+$g_tcp+$g_rcon
    },
    "sys":{"cpu":$cpu,"mem":$mem,"conn":$conn,"uptime":$uptime},
    "blocked_rules":$blk
})
json.dump(d,open(f,"w"))
PY
}

# ── Terminal TUI ──────────────────────────────────────────────────────
tui() {
    while true; do
        clear
        local iface; iface=$(ip route 2>/dev/null | awk '/default/{print $5;exit}')
        local blk; blk=$(iptables -L EG_L4 -n 2>/dev/null | grep -c "^DROP" || echo 0)
        local conn; conn=$(ss -tn state established 2>/dev/null | wc -l)
        local cpu; cpu=$(awk '{printf "%.0f%%",$1*100/'"$(nproc 2>/dev/null||echo 1)"'}' /proc/loadavg)
        local mem; mem=$(free 2>/dev/null | awk '/Mem:/{printf "%.0f%%",$3/$2*100}')
        local bps_in pps_in
        bps_in=$(python3 -c "import json;d=json.load(open('$STATS'));print(d['net'].get('bps_in',0))" 2>/dev/null || echo 0)
        pps_in=$(python3 -c "import json;d=json.load(open('$STATS'));print(d['net'].get('pps_in',0))" 2>/dev/null || echo 0)
        echo -e "${W}"
        echo "  ╔══════════════════════════════════════════════════════════════════════╗"
        echo "  ║  🦅  EAGLE GUARD v5.0  ·  L4 / L7 / GAME DDoS Protection           ║"
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        printf "  ║  %-36s  %-33s║\n" "⏰ $(date '+%Y-%m-%d %H:%M:%S')" "🖥  $(hostname) — ${iface:-eth0}"
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        printf "  ║  ${G}● AKTİF${N}   Engel:${R}%-5s${N}  Bağlantı:${C}%-5s${N}  CPU:${Y}%-7s${N}  RAM:${Y}%-7s${N} ║\n" \
            "$blk" "$conn" "$cpu" "$mem"
        printf "  ║  📥 IN: $(echo $bps_in | awk '{printf "%.2f MB/s  %d pkt/s",$1/1048576,$1}')%-41s║\n" ""
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        echo -e "  ║  ${C}[L4]${N} SYN Flood ✓  ICMP Flood ✓  XMAS/NULL ✓  Frag ✓  Bogon ✓     ║"
        echo -e "  ║       Port Scan ✓  Amplification ✓  IP/s Limit ✓  SSH Protect ✓   ║"
        echo -e "  ║  ${Y}[L7]${N} HTTP Flood ✓  HTTPS Flood ✓  FTP Brute ✓               ║"
        echo -e "  ║  ${G}[GM]${N} UDP Flood ✓  TCP Flood ✓  RCON Brute ✓  Fake Connect ✓  ║"
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        echo "  ║  Web: http://$(hostname -I 2>/dev/null | awk '{print $1}')/eagle-guard/  [Q] Çıkış      ║"
        echo -e "  ╚══════════════════════════════════════════════════════════════════════╝${N}"
        read -t 4 -n 1 k 2>/dev/null
        [[ "$k" == "q" || "$k" == "Q" ]] && break
    done
}

# ════════════════════════════════════════════════════════════════════
# HELP
# ════════════════════════════════════════════════════════════════════
show_help() {
    echo -e "${C}"
    echo "  ╔══════════════════════════════════════════════════════════════════════╗"
    echo "  ║  🦅  Eagle Guard v5.0 — Yardım                                       ║"
    echo "  ╠══════════════════════════════════════════════════════════════════════╣"
    echo -e "  ║${N}"
    echo -e "  ${W}KOMUTLAR:${N}"
    echo -e "  ${G}eagle-guard start${N}          Korumayı başlat (L4+L7+Game)"
    echo -e "  ${G}eagle-guard stop${N}           Korumayı durdur"
    echo -e "  ${G}eagle-guard restart${N}        Yeniden başlat"
    echo -e "  ${G}eagle-guard status${N}         TUI durum ekranı"
    echo -e "  ${G}eagle-guard stats${N}          JSON istatistik"
    echo -e "  ${G}eagle-guard block <IP>${N}     IP'yi manuel engelle"
    echo -e "  ${G}eagle-guard unblock <IP>${N}   IP engelini kaldır"
    echo -e "  ${G}eagle-guard rules-l4${N}       Layer 4 kuralları"
    echo -e "  ${G}eagle-guard rules-l7${N}       Layer 7 kuralları"
    echo -e "  ${G}eagle-guard rules-game${N}     Game Layer kuralları"
    echo -e "  ${G}eagle-guard logs [N]${N}       Son N log satırı (varsayılan:100)"
    echo -e "  ${G}eagle-guard game-on${N}        Game korumasını aç"
    echo -e "  ${G}eagle-guard game-off${N}       Game korumasını kapat"
    echo -e "  ${G}eagle-guard help${N}           Bu yardım ekranı"
    echo ""
    echo -e "  ${W}KORUMA KATMANLARI:${N}"
    echo -e "  ${C}[L4] Network/Transport:${N}"
    echo -e "       SYN Flood, ICMP Flood, XMAS/NULL Scan, Frag Packet"
    echo -e "       Bogon IP, Amplification (DNS/NTP/SSDP), Port Scan"
    echo -e "       IP başına rate limit, SSH brute force koruması"
    echo -e "  ${Y}[L7] Application:${N}"
    echo -e "       HTTP/HTTPS Flood, FTP Brute Force"
    echo -e "       IP başına bağlantı ve istek hız limiti"
    echo -e "  ${G}[GM] Game Server:${N}"
    echo -e "       UDP Flood, TCP Conn Flood, Fake Connect"
    echo -e "       RCON Brute Force, Oversized/Tiny UDP Drop"
    echo -e "       CS2/GO, Minecraft, FiveM, Unreal, TS3, DayZ, Rust"
    echo ""
    echo -e "  ${W}DOSYALAR:${N}"
    echo -e "  ${C}/opt/eagle-guard/config/eagle.conf${N}    Konfigürasyon"
    echo -e "  ${C}/opt/eagle-guard/config/whitelist.txt${N} Engellenmeyen IP'ler"
    echo -e "  ${C}/opt/eagle-guard/logs/eagle.log${N}       Log dosyası"
    echo -e "  ${C}/opt/eagle-guard/data/stats.json${N}      Canlı istatistik"
    echo ""
    echo -e "  ${W}WEB ARAYÜZÜ:${N} http://$(hostname -I 2>/dev/null | awk '{print $1}')/eagle-guard/"
    echo ""
}

# ════════════════════════════════════════════════════════════════════
# ANA KOMUTLAR
# ════════════════════════════════════════════════════════════════════
case "${1:-help}" in
    start)
        [[ -f "$PID" ]] && kill -0 "$(cat $PID)" 2>/dev/null && \
            { echo -e "${Y}Eagle Guard zaten çalışıyor${N}"; exit 0; }
        load_conf
        setup
        kernel_harden
        l4_apply
        l7_apply
        game_apply
        echo $$ > "$PID"
        log OK "Eagle Guard v5.0 başlatıldı (PID:$$) — SSH ve Web kesintisi YOK"
        alert_push system "🦅 Eagle Guard v5.0 Başlatıldı" "L4+L7+Game aktif" low
        while true; do
            load_conf
            collect
            sleep "$INTERVAL"
        done
        ;;
    stop)
        load_conf
        setup
        rules_remove
        kernel_reset
        python3 -c "
import json
try:
    d=json.load(open('$STATS')); d['status']='inactive'
    json.dump(d,open('$STATS','w'))
except: pass" 2>/dev/null
        alert_push system "Eagle Guard Durduruldu" "Koruma devre dışı" medium
        kill "$(cat $PID 2>/dev/null)" 2>/dev/null
        rm -f "$PID"
        log OK "Eagle Guard durduruldu"
        ;;
    restart)
        "$0" stop
        sleep 2
        exec "$0" start
        ;;
    status)
        load_conf; setup; tui
        ;;
    block)
        [[ -z "$2" ]] && { echo "Kullanım: eagle-guard block <IP>"; exit 1; }
        load_conf; setup
        ip_block "$2" "${3:-manual_cli}" "${4:-L4}"
        ;;
    unblock)
        [[ -z "$2" ]] && { echo "Kullanım: eagle-guard unblock <IP>"; exit 1; }
        load_conf; setup
        ip_unblock "$2" manual_cli
        ;;
    stats)
        python3 -m json.tool "$STATS" 2>/dev/null || echo "Stats dosyası bulunamadı"
        ;;
    rules-l4)
        iptables -L EG_L4 -nvx 2>/dev/null || echo "EG_L4 zinciri bulunamadı (servis çalışıyor mu?)"
        ;;
    rules-l7)
        iptables -L EG_L7 -nvx 2>/dev/null || echo "EG_L7 zinciri bulunamadı"
        ;;
    rules-game)
        iptables -L EG_GAME -nvx 2>/dev/null || echo "EG_GAME zinciri bulunamadı"
        ;;
    logs)
        tail -"${2:-100}" "$LOG" 2>/dev/null || echo "Log dosyası bulunamadı: $LOG"
        ;;
    game-on)
        load_conf; setup
        iptables -D INPUT -j EG_GAME 2>/dev/null
        iptables -F EG_GAME 2>/dev/null
        iptables -X EG_GAME 2>/dev/null
        iptables -N EG_GAME 2>/dev/null
        iptables -I INPUT 3 -j EG_GAME
        game_apply
        log OK "Game koruması etkinleştirildi"
        ;;
    game-off)
        iptables -D INPUT -j EG_GAME 2>/dev/null
        iptables -F EG_GAME 2>/dev/null
        iptables -X EG_GAME 2>/dev/null
        log OK "Game koruması devre dışı"
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo -e "${Y}Bilinmeyen komut: $1${N}"
        show_help
        ;;
esac
