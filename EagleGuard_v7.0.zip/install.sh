#!/bin/bash
# Eagle Guard v5.0 — Otomatik Kurulum
# Kullanım: sudo bash install.sh
R='\033[0;31m' G='\033[0;32m' Y='\033[1;33m' C='\033[0;36m' W='\033[1;37m' N='\033[0m'
ERRORS=0
LOG="/tmp/eagle-install-$(date +%Y%m%d-%H%M%S).log"

ok()   { echo -e "${G}  [OK]${N} $*";  echo "[OK] $*"  >> "$LOG"; }
info() { echo -e "${C}  [..]${N} $*";  echo "[..] $*"  >> "$LOG"; }
warn() { echo -e "${Y}  [!!]${N} $*";  echo "[!!] $*"  >> "$LOG"; }
fail() { echo -e "${R}  [XX]${N} $*";  echo "[XX] $*"  >> "$LOG"; ERRORS=$((ERRORS+1)); }
step() { echo -e "\n${W}━━━ $* ━━━${N}"; }

cp_f() {
    # cp_f kaynak hedef açıklama
    if [ ! -f "$1" ]; then fail "Kaynak yok: $1"; return 1; fi
    cp -f "$1" "$2" 2>>"$LOG" && ok "$3" || fail "Kopyalanamadı: $1 → $2"
}

SDIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"

echo -e "\n${C}  ═══════════════════════════════════════════════════${N}"
echo -e "${W}    🦅  Eagle Guard v5.0 — Kurulum${N}"
echo -e "${C}  ═══════════════════════════════════════════════════${N}"
echo "  Kaynak: $SDIR | Log: $LOG"
echo ""

# Root
[ "$(id -u)" != "0" ] && { echo -e "${R}sudo bash install.sh gerekli${N}"; exit 1; }
ok "Root yetkisi var"

# Kaynak dosya kontrol
step "KAYNAK DOSYALAR"
MISS=0
for f in \
    "$SDIR/scripts/eagle-guard.sh" \
    "$SDIR/web/index.php" \
    "$SDIR/web/api/index.php" \
    "$SDIR/systemd/eagle-guard.service" \
    "$SDIR/config/eagle.conf"
do
    [ -f "$f" ] && ok "$(basename $f)" || { fail "EKSİK: $f"; MISS=$((MISS+1)); }
done
[ "$MISS" -gt 0 ] && { echo -e "\n${R}$MISS dosya eksik. ZIP'i tekrar açın.${N}"; exit 1; }

# Mevcut kurulum varsa temizle
step "MEVCUT KURULUM KONTROLÜ"
if [ -f /opt/eagle-guard/scripts/eagle-guard.sh ]; then
    warn "Mevcut kurulum tespit edildi — temizleniyor..."
    systemctl stop eagle-guard 2>/dev/null || true
    systemctl disable eagle-guard 2>/dev/null || true
    rm -f /var/run/eagle-guard.pid
    for chain in EG_L4 EG_L4_FWD EG_L7 EG_GAME; do
        iptables -D INPUT -j "$chain" 2>/dev/null || true
        iptables -F "$chain" 2>/dev/null || true
        iptables -X "$chain" 2>/dev/null || true
    done
    ip6tables -D INPUT -j EG_L4_6 2>/dev/null || true
    ip6tables -F EG_L4_6 2>/dev/null || true
    ip6tables -X EG_L4_6 2>/dev/null || true
    # Script ve web sil, config/data koru
    rm -f /opt/eagle-guard/scripts/eagle-guard.sh
    rm -rf /var/www/html/eagle-guard
    rm -f /etc/systemd/system/eagle-guard.service
    rm -f /usr/local/bin/eagle-guard
    ok "Eski kurulum temizlendi (config/data korundu)"
else
    ok "Mevcut kurulum yok — temiz kurulum"
fi

# Paketler
step "PAKET KURULUMU"
apt-get update -y >> "$LOG" 2>&1 && ok "apt update" || warn "apt update başarısız"
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    iptables python3 curl wget iproute2 procps net-tools \
    apache2 php libapache2-mod-php php-json acl >> "$LOG" 2>&1 \
    && ok "Temel paketler" || warn "Bazı paketler kurulamadı"
DEBIAN_FRONTEND=noninteractive apt-get install -y iptables-persistent >> "$LOG" 2>&1 || true
DEBIAN_FRONTEND=noninteractive apt-get install -y ip6tables >> "$LOG" 2>&1 || true
DEBIAN_FRONTEND=noninteractive apt-get install -y mailutils  >> "$LOG" 2>&1 || true

# Dizinler
step "DİZİNLER"
mkdir -p /opt/eagle-guard/{scripts,data,logs,config,tmp}
ok "Oluşturuldu: /opt/eagle-guard/"
mkdir -p /var/www/html/eagle-guard/api
ok "Oluşturuldu: /var/www/html/eagle-guard/"

# Dosyaları kopyala
step "DOSYALAR KOPYALANIYOR"
WEB=/var/www/html/eagle-guard
cp_f "$SDIR/scripts/eagle-guard.sh" "/opt/eagle-guard/scripts/eagle-guard.sh" "eagle-guard.sh"
chmod +x /opt/eagle-guard/scripts/eagle-guard.sh
ln -sf /opt/eagle-guard/scripts/eagle-guard.sh /usr/local/bin/eagle-guard
ok "Global komut: eagle-guard"

cp_f "$SDIR/web/index.php"     "$WEB/index.php"     "web/index.php → $WEB"
cp_f "$SDIR/web/api/index.php" "$WEB/api/index.php" "web/api/index.php → $WEB/api"

# uninstall ve fix — /opt/eagle-guard içine koy
[ -f "$SDIR/uninstall.sh" ] && {
    cp_f "$SDIR/uninstall.sh" "/opt/eagle-guard/uninstall.sh" "uninstall.sh"
    chmod +x /opt/eagle-guard/uninstall.sh
}
[ -f "$SDIR/fix.sh" ] && {
    cp_f "$SDIR/fix.sh" "/opt/eagle-guard/fix.sh" "fix.sh"
    chmod +x /opt/eagle-guard/fix.sh
}

# Config (varsa üzerine yazma)
if [ ! -f /opt/eagle-guard/config/eagle.conf ]; then
    cp_f "$SDIR/config/eagle.conf" "/opt/eagle-guard/config/eagle.conf" "eagle.conf"
else
    ok "eagle.conf korundu (üzerine yazılmadı)"
fi

# whitelist
if [ ! -f /opt/eagle-guard/config/whitelist.txt ]; then
    [ -f "$SDIR/config/whitelist.txt" ] \
        && cp_f "$SDIR/config/whitelist.txt" "/opt/eagle-guard/config/whitelist.txt" "whitelist.txt" \
        || { printf "127.0.0.1\n::1\n" > /opt/eagle-guard/config/whitelist.txt; ok "whitelist.txt oluşturuldu"; }
else
    ok "whitelist.txt korundu"
fi

# JSON veri dosyaları
[ ! -f /opt/eagle-guard/data/blocked.json ] && echo '{"blocked":[]}' > /opt/eagle-guard/data/blocked.json
[ ! -f /opt/eagle-guard/data/alerts.json  ] && echo '{"alerts":[]}'  > /opt/eagle-guard/data/alerts.json
[ ! -f /opt/eagle-guard/data/traffic.json ] && echo '{"points":[]}'  > /opt/eagle-guard/data/traffic.json
echo '{"status":"inactive","net":{"bps_in":0,"bps_out":0,"pps_in":0,"pps_out":0},"l4":{},"l7":{},"game":{},"sys":{"cpu":0,"mem":0,"conn":0,"uptime":0}}' \
    > /opt/eagle-guard/data/stats.json
ok "JSON veri dosyaları hazır"

cat > "$WEB/.htaccess" << 'HTA'
Options -Indexes
DirectoryIndex index.php
HTA
ok ".htaccess oluşturuldu"

# İzinler
step "İZİNLER"
chown -R www-data:www-data "$WEB" >> "$LOG" 2>&1 || true
chmod -R 755 "$WEB" >> "$LOG" 2>&1 || true
if command -v setfacl >/dev/null 2>&1; then
    setfacl -R -m u:www-data:rwx /opt/eagle-guard/data/   >> "$LOG" 2>&1 || true
    setfacl -R -m u:www-data:rx  /opt/eagle-guard/logs/   >> "$LOG" 2>&1 || true
    setfacl -R -m u:www-data:r   /opt/eagle-guard/config/ >> "$LOG" 2>&1 || true
    ok "ACL izinleri ayarlandı"
else
    chmod 777 /opt/eagle-guard/data/       >> "$LOG" 2>&1 || true
    chmod 666 /opt/eagle-guard/data/*.json >> "$LOG" 2>&1 || true
    ok "chmod izinleri ayarlandı"
fi
chmod +x /opt/eagle-guard/scripts/eagle-guard.sh

# Sudoers
step "SUDO İZİNLERİ"
cat > /etc/sudoers.d/eagle-guard << 'SUDO'
Defaults:www-data !requiretty
www-data ALL=(root) NOPASSWD: /opt/eagle-guard/scripts/eagle-guard.sh
www-data ALL=(root) NOPASSWD: /sbin/iptables
www-data ALL=(root) NOPASSWD: /usr/sbin/iptables
www-data ALL=(root) NOPASSWD: /sbin/ip6tables
www-data ALL=(root) NOPASSWD: /usr/sbin/ip6tables
SUDO
chmod 440 /etc/sudoers.d/eagle-guard
ok "sudoers ayarlandı"
visudo -c -f /etc/sudoers.d/eagle-guard >> "$LOG" 2>&1 \
    && ok "sudoers syntax doğrulandı" || warn "sudoers syntax uyarısı"

# Apache
step "APACHE"
systemctl start apache2  >> "$LOG" 2>&1 || service apache2 start >> "$LOG" 2>&1 || true
systemctl enable apache2 >> "$LOG" 2>&1 || true
a2enmod rewrite >> "$LOG" 2>&1 || true
PHP_MOD=$(ls /etc/apache2/mods-available/php*.load 2>/dev/null | head -1 | xargs basename 2>/dev/null | sed 's/.load//')
[ -n "$PHP_MOD" ] && { a2enmod "$PHP_MOD" >> "$LOG" 2>&1 || true; ok "PHP: $PHP_MOD"; }
for cf in /etc/apache2/sites-available/000-default.conf /etc/apache2/apache2.conf; do
    [ -f "$cf" ] && grep -q "AllowOverride None" "$cf" 2>/dev/null && \
        sed -i 's/AllowOverride None/AllowOverride All/g' "$cf" && ok "AllowOverride All: $(basename $cf)"
done
cat > /etc/apache2/conf-available/eagle-guard.conf << 'ACONF'
<Directory /var/www/html/eagle-guard>
    Options -Indexes +FollowSymLinks
    AllowOverride All
    Require all granted
    DirectoryIndex index.php
</Directory>
ACONF
a2enconf eagle-guard >> "$LOG" 2>&1 || true
systemctl reload apache2 >> "$LOG" 2>&1 || systemctl restart apache2 >> "$LOG" 2>&1 || true
ok "Apache yapılandırıldı"

# Systemd
step "SYSTEMD SERVİSİ"
cp_f "$SDIR/systemd/eagle-guard.service" "/etc/systemd/system/eagle-guard.service" "eagle-guard.service"
systemctl daemon-reload  >> "$LOG" 2>&1 || true
systemctl enable eagle-guard >> "$LOG" 2>&1 || true
ok "Servis enable edildi (boot'ta otomatik başlar)"

# Logrotate
cat > /etc/logrotate.d/eagle-guard << 'LR'
/opt/eagle-guard/logs/*.log {
    daily
    rotate 14
    compress
    missingok
    notifempty
    create 644 root root
}
LR
ok "logrotate ayarlandı"

# Servis kurulumda BAŞLATILMIYOR — SSH güvenliği için manuel başlat
step "SERVİS HAZIR"
ok "Eagle Guard servisi enable edildi (boot'ta başlar)"
warn "Kurulum sırasında servis OTOMATİK BAŞLATILMIYOR"
warn "SSH bağlantınızı kaybetmemek için manuel başlatın:"
echo -e "\n  ${W}sudo systemctl start eagle-guard${N}\n"

# Doğrulama
step "DOĞRULAMA"
ck() { [ -f "$2" ] && ok "$1" || fail "$1 EKSİK: $2"; }
ck "eagle-guard.sh"    "/opt/eagle-guard/scripts/eagle-guard.sh"
ck "web/index.php"     "/var/www/html/eagle-guard/index.php"
ck "web/api/index.php" "/var/www/html/eagle-guard/api/index.php"
ck "systemd service"   "/etc/systemd/system/eagle-guard.service"
ck "sudoers"           "/etc/sudoers.d/eagle-guard"

HTTP=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 http://localhost/eagle-guard/ 2>/dev/null || echo 000)
[ "$HTTP" = "200" ] && ok "HTTP 200 OK ✓" || warn "HTTP $HTTP — Apache log: tail -20 /var/log/apache2/error.log"

API=$(curl -s --connect-timeout 5 "http://localhost/eagle-guard/api/index.php?action=debug" 2>/dev/null || echo "")
echo "$API" | grep -q '"ok":true' && ok "API çalışıyor ✓" || warn "API yanıt vermiyor"

# Özet
IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "SUNUCU_IP")
echo ""
[ "$ERRORS" -eq 0 ] && \
    echo -e "${G}┌─────────────────────────────────────────────────────┐\n│  ✅  Eagle Guard v5.0 KURULUM BAŞARILI              │\n└─────────────────────────────────────────────────────┘${N}" || \
    echo -e "${Y}┌─────────────────────────────────────────────────────┐\n│  ⚠  KURULUM TAMAMLANDI — ${ERRORS} SORUN         │\n└─────────────────────────────────────────────────────┘${N}"
echo ""
echo -e "  ${G}🌐 Web:${N}      http://${IP}/eagle-guard/"
echo -e "  ${G}🔍 Debug:${N}    http://${IP}/eagle-guard/api/index.php?action=debug"
echo -e "  ${G}⏻ Başlat:${N}    sudo systemctl start eagle-guard"
echo -e "  ${Y}⚠  NOT:${N}       Servisi başlatmadan önce SSH bağlantınızın"
echo -e "             açık olduğunu kontrol edin!"
echo -e "  ${G}⏸ Durdur:${N}    sudo systemctl stop eagle-guard"
echo -e "  ${G}📋 Log:${N}       sudo eagle-guard logs"
echo -e "  ${G}❓ Yardım:${N}    sudo eagle-guard help"
echo -e "  ${G}🗑 Kaldır:${N}    sudo bash /opt/eagle-guard/uninstall.sh"
echo -e "  ${G}📄 Kurulum log:${N} $LOG"
echo ""
