#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════════╗
# ║  EAGLE GUARD v5.1 — L4 / L7 / GAME DDoS Protection                  ║
# ║  SSH ve Web KESİNTİSİ YOK — EG_ACCEPT zinciri ile korunur           ║
# ╚══════════════════════════════════════════════════════════════════════╝
EAGLE_DIR="/opt/eagle-guard"
LOG="$EAGLE_DIR/logs/eagle.log"
STATS="$EAGLE_DIR/data/stats.json"
BLOCKED="$EAGLE_DIR/data/blocked.json"
ALERTS="$EAGLE_DIR/data/alerts.json"
TRAFFIC="$EAGLE_DIR/data/traffic.json"
CONF="$EAGLE_DIR/config/eagle.conf"
WL="$EAGLE_DIR/config/whitelist.txt"
PID="/var/run/eagle-guard.pid"
R='\033[0;31m' G='\033[0;32m' Y='\033[1;33m' C='\033[0;36m' W='\033[1;37m' N='\033[0m'

load_conf() {
    L4_SYN_RATE=200; L4_SYN_BURST=1000; L4_ICMP_RATE=100
    L4_SYN_PER_IP=40; L4_CONN_PER_IP=300
    L7_HTTP_CONN=100; L7_HTTP_RATE=80; L7_SSH_RATE=6
    GAME_ENABLED=yes; GAME_UDP_PPS=3000; GAME_UDP_BURST=8000
    GAME_TCP_CONN=80
    GAME_PORTS_UDP="27015,27016,27017,27018,7777,7778,19132,19133,25565,25575,2302,2303,9987,30120,64090,2456,2457,28015"
    GAME_PORTS_TCP="27015,27016,7777,25565,25575,2302,30120,64090,9987,28015"
    ALERT_PPS=15000; ALERT_BPS=209715200; ALERT_CONN=8000
    BAN_TIME=3600; INTERVAL=3; AUTO_BLOCK=yes; AUTOBLOCK_HITS=20
    WEBHOOK=""; EMAIL=""; TG_BOT=""; TG_CHAT=""
    [[ -f "$CONF" ]] && source "$CONF" 2>/dev/null || true
}

log() {
    local l=$1; shift
    mkdir -p "$(dirname $LOG)" 2>/dev/null
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$l] $*" >> "$LOG"
    case $l in
        ALERT) echo -e "${R}[ALERT]${N} $*";;
        OK)    echo -e "${G}[OK]${N}    $*";;
        INFO)  echo -e "${C}[INFO]${N}  $*";;
        WARN)  echo -e "${Y}[WARN]${N}  $*";;
        GAME)  echo -e "${C}[GAME]${N}  $*";;
    esac
}

setup() {
    mkdir -p "$EAGLE_DIR"/{logs,data,config}
    [[ ! -f "$WL" ]] && printf "127.0.0.1\n::1\n" > "$WL"
    if [[ ! -f "$CONF" ]]; then
        cat > "$CONF" << 'DEFCONF'
L4_SYN_RATE=200
L4_SYN_BURST=1000
L4_ICMP_RATE=100
L4_SYN_PER_IP=40
L4_CONN_PER_IP=300
L7_HTTP_CONN=100
L7_HTTP_RATE=80
L7_SSH_RATE=6
GAME_ENABLED=yes
GAME_UDP_PPS=3000
GAME_UDP_BURST=8000
GAME_TCP_CONN=80
GAME_PORTS_UDP=27015,27016,27017,27018,7777,7778,19132,19133,25565,25575,2302,2303,9987,30120,64090
GAME_PORTS_TCP=27015,27016,7777,25565,25575,2302,30120,64090,9987
ALERT_PPS=15000
ALERT_BPS=209715200
ALERT_CONN=8000
BAN_TIME=3600
INTERVAL=3
AUTO_BLOCK=yes
AUTOBLOCK_HITS=20
WEBHOOK=
EMAIL=
TG_BOT=
TG_CHAT=
DEFCONF
    fi
    [[ ! -f "$BLOCKED" ]] && echo '{"blocked":[]}' > "$BLOCKED"
    [[ ! -f "$ALERTS"  ]] && echo '{"alerts":[]}'  > "$ALERTS"
    [[ ! -f "$TRAFFIC" ]] && echo '{"points":[]}'  > "$TRAFFIC"
    chmod 666 "$EAGLE_DIR/data/"*.json 2>/dev/null || true
    chmod 777 "$EAGLE_DIR/data/" 2>/dev/null || true
    python3 -c "
import json,datetime
f='$STATS'
try: d=json.load(open(f))
except: d={}
if 'status' not in d:
    d.update({'status':'inactive','version':'5.1',
      'start_time':datetime.datetime.utcnow().isoformat()+'Z',
      'l4':{},'l7':{},'game':{},
      'net':{'bps_in':0,'bps_out':0,'pps_in':0,'pps_out':0,'bytes_in':0,'bytes_out':0,'pkts_in':0,'pkts_out':0},
      'sys':{'cpu':0,'mem':0,'conn':0,'uptime':0},'blocked_rules':0})
    json.dump(d,open(f,'w'))
" 2>/dev/null || true
    chmod 666 "$STATS" 2>/dev/null || true
}

kernel_harden() {
    log INFO "Kernel parametreleri uygulanıyor..."
    sysctl -w net.ipv4.tcp_syncookies=1 net.ipv4.tcp_max_syn_backlog=32768 \
        net.ipv4.tcp_fin_timeout=15 net.ipv4.tcp_tw_reuse=1 \
        net.ipv4.conf.all.rp_filter=1 net.ipv4.conf.default.rp_filter=1 \
        net.ipv4.conf.all.accept_source_route=0 net.ipv4.conf.all.accept_redirects=0 \
        net.ipv4.conf.all.send_redirects=0 net.ipv4.conf.all.log_martians=1 \
        net.ipv4.icmp_echo_ignore_broadcasts=1 \
        net.core.rmem_max=134217728 net.core.wmem_max=134217728 \
        net.core.netdev_max_backlog=10000 net.core.somaxconn=65535 \
        >/dev/null 2>&1 || true
    sysctl -w net.nf_conntrack_max=1048576 >/dev/null 2>&1 || true
    log OK "Kernel hardening tamamlandı"
}

kernel_reset() {
    sysctl -w net.ipv4.tcp_syncookies=1 net.ipv4.conf.all.rp_filter=1 \
        net.ipv4.conf.all.log_martians=0 >/dev/null 2>&1 || true
}

apply_rules() {
    log INFO "Firewall kuralları uygulanıyor..."

    for c in EG_ACCEPT EG_L4 EG_L7 EG_GAME; do
        iptables -D INPUT   -j "$c" 2>/dev/null
        iptables -D FORWARD -j "$c" 2>/dev/null
        iptables -F "$c" 2>/dev/null
        iptables -X "$c" 2>/dev/null
        iptables -N "$c"
    done
    ip6tables -D INPUT -j EG_L4_6 2>/dev/null
    ip6tables -F EG_L4_6 2>/dev/null; ip6tables -X EG_L4_6 2>/dev/null
    ip6tables -N EG_L4_6 2>/dev/null

    # SIRA: ACCEPT → L4 → L7 → GAME
    iptables -I INPUT 1 -j EG_ACCEPT
    iptables -I INPUT 2 -j EG_L4
    iptables -I INPUT 3 -j EG_L7
    iptables -I INPUT 4 -j EG_GAME
    ip6tables -I INPUT 1 -j EG_L4_6 2>/dev/null

    # ─── EG_ACCEPT — SSH/Web/Whitelist BURADA ACCEPT EDİLİR ───────────
    # ACCEPT = sonraki zincirlere (L4,L7) DÜŞMEz
    iptables -A EG_ACCEPT -i lo -j ACCEPT
    iptables -A EG_ACCEPT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
    iptables -A EG_ACCEPT -m conntrack --ctstate INVALID -j DROP

    while IFS= read -r ip; do
        [[ -z "$ip" || "$ip" == \#* ]] && continue
        [[ "$ip" =~ : ]] \
            && ip6tables -A EG_L4_6 -s "$ip" -j ACCEPT 2>/dev/null \
            || iptables  -A EG_ACCEPT -s "$ip" -j ACCEPT 2>/dev/null
    done < "$WL"

    # SSH brute force koruması (rate limit) + geçiş
    iptables -A EG_ACCEPT -p tcp --dport 22 --syn \
        -m hashlimit --hashlimit-name ssh_bf \
        --hashlimit-above "${L7_SSH_RATE}/min" \
        --hashlimit-mode srcip --hashlimit-burst 10 \
        -j LOG --log-prefix "[EG-SSH-BF] " --log-level 4 2>/dev/null
    iptables -A EG_ACCEPT -p tcp --dport 22 --syn \
        -m hashlimit --hashlimit-name ssh_bf \
        --hashlimit-above "${L7_SSH_RATE}/min" \
        --hashlimit-mode srcip --hashlimit-burst 10 -j DROP 2>/dev/null
    iptables -A EG_ACCEPT -p tcp --dport 22  -j ACCEPT
    iptables -A EG_ACCEPT -p tcp --dport 80  -j ACCEPT
    iptables -A EG_ACCEPT -p tcp --dport 443 -j ACCEPT

    # ─── EG_L4 — SALDIRI FİLTRELEME ──────────────────────────────────
    iptables -A EG_L4 -p tcp --tcp-flags ALL ALL  -j LOG --log-prefix "[EG-L4-XMAS] " --log-level 4
    iptables -A EG_L4 -p tcp --tcp-flags ALL ALL  -j DROP
    iptables -A EG_L4 -p tcp --tcp-flags ALL NONE -j LOG --log-prefix "[EG-L4-NULL] " --log-level 4
    iptables -A EG_L4 -p tcp --tcp-flags ALL NONE -j DROP
    iptables -A EG_L4 -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP
    iptables -A EG_L4 -p tcp --tcp-flags SYN,RST SYN,RST -j DROP

    iptables -A EG_L4 -p tcp --syn \
        -m limit --limit "${L4_SYN_RATE}/s" --limit-burst "$L4_SYN_BURST" -j RETURN
    iptables -A EG_L4 -p tcp --syn \
        -j LOG --log-prefix "[EG-L4-SYN] " --log-level 4
    iptables -A EG_L4 -p tcp --syn -j DROP

    iptables -A EG_L4 -p tcp --syn \
        -m hashlimit --hashlimit-name syn_ip \
        --hashlimit-above "${L4_SYN_PER_IP}/sec" \
        --hashlimit-mode srcip --hashlimit-burst $((L4_SYN_PER_IP*3)) \
        -j DROP 2>/dev/null

    iptables -A EG_L4 -p tcp \
        -m connlimit --connlimit-above "$L4_CONN_PER_IP" --connlimit-mask 32 \
        -j LOG --log-prefix "[EG-L4-CLIM] " --log-level 4
    iptables -A EG_L4 -p tcp \
        -m connlimit --connlimit-above "$L4_CONN_PER_IP" --connlimit-mask 32 -j DROP

    iptables -A EG_L4 -p icmp --icmp-type echo-request \
        -m limit --limit "${L4_ICMP_RATE}/s" --limit-burst $((L4_ICMP_RATE*2)) -j RETURN
    iptables -A EG_L4 -p icmp --icmp-type echo-request \
        -j LOG --log-prefix "[EG-L4-ICMP] " --log-level 4
    iptables -A EG_L4 -p icmp --icmp-type echo-request -j DROP
    iptables -A EG_L4 -p icmp -j RETURN

    iptables -A EG_L4 -f -j LOG --log-prefix "[EG-L4-FRAG] " --log-level 4
    iptables -A EG_L4 -f -j DROP

    for bogon in "0.0.0.0/8" "100.64.0.0/10" "169.254.0.0/16" \
                  "192.0.2.0/24" "198.51.100.0/24" "203.0.113.0/24" \
                  "224.0.0.0/4" "240.0.0.0/4"; do
        iptables -A EG_L4 -s "$bogon" -j DROP 2>/dev/null
    done

    iptables -A EG_L4 -p udp --dport 1900  -j DROP
    iptables -A EG_L4 -p udp --dport 11211 -j DROP
    iptables -A EG_L4 -p udp --dport 19    -j DROP
    iptables -A EG_L4 -p udp --dport 17    -j DROP

    iptables -A EG_L4 -p udp --dport 53 \
        -m hashlimit --hashlimit-name dns_rl \
        --hashlimit-above "60/sec" --hashlimit-mode srcip \
        --hashlimit-burst 120 -j DROP 2>/dev/null
    iptables -A EG_L4 -p udp --dport 123 \
        -m hashlimit --hashlimit-name ntp_rl \
        --hashlimit-above "20/sec" --hashlimit-mode srcip \
        --hashlimit-burst 40 -j DROP 2>/dev/null

    iptables -A EG_L4 -m recent --name EG_SCAN \
        --rcheck --seconds 60 --hitcount 30 \
        -j LOG --log-prefix "[EG-L4-SCAN] " --log-level 4
    iptables -A EG_L4 -m recent --name EG_SCAN \
        --rcheck --seconds 60 --hitcount 30 -j DROP
    iptables -A EG_L4 -m recent --name EG_SCAN --set -j RETURN

    # ─── EG_L7 — FTP BRUTE FORCE ──────────────────────────────────────
    iptables -A EG_L7 -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
    iptables -A EG_L7 -p tcp --dport 21 \
        -m hashlimit --hashlimit-name ftp_bf \
        --hashlimit-above "10/min" --hashlimit-mode srcip \
        --hashlimit-burst 15 -j DROP 2>/dev/null

    # ─── EG_GAME — OYUN SUNUCUSU ──────────────────────────────────────
    if [[ "$GAME_ENABLED" == "yes" ]]; then
        iptables -A EG_GAME -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
        iptables -A EG_GAME -i lo -j RETURN

        IFS=',' read -ra UPORTS <<< "$GAME_PORTS_UDP"
        for port in "${UPORTS[@]}"; do
            port=$(echo "$port" | tr -d ' ')
            [[ -z "$port" ]] && continue
            iptables -A EG_GAME -p udp --dport "$port" \
                -m hashlimit --hashlimit-name "gu${port}" \
                --hashlimit-above "${GAME_UDP_PPS}/sec" \
                --hashlimit-mode srcip \
                --hashlimit-burst "$GAME_UDP_BURST" \
                -j LOG --log-prefix "[EG-GAME-UDP] " --log-level 4 2>/dev/null
            iptables -A EG_GAME -p udp --dport "$port" \
                -m hashlimit --hashlimit-name "gu${port}" \
                --hashlimit-above "${GAME_UDP_PPS}/sec" \
                --hashlimit-mode srcip \
                --hashlimit-burst "$GAME_UDP_BURST" -j DROP 2>/dev/null
            iptables -A EG_GAME -p udp --dport "$port" \
                -m length --length 0:15 -j DROP 2>/dev/null
        done

        IFS=',' read -ra TPORTS <<< "$GAME_PORTS_TCP"
        for port in "${TPORTS[@]}"; do
            port=$(echo "$port" | tr -d ' ')
            [[ -z "$port" ]] && continue
            iptables -A EG_GAME -p tcp --dport "$port" \
                -m connlimit --connlimit-above "$GAME_TCP_CONN" --connlimit-mask 32 \
                -j LOG --log-prefix "[EG-GAME-TCP] " --log-level 4
            iptables -A EG_GAME -p tcp --dport "$port" \
                -m connlimit --connlimit-above "$GAME_TCP_CONN" --connlimit-mask 32 -j DROP
            iptables -A EG_GAME -p tcp --dport "$port" --syn \
                -m hashlimit --hashlimit-name "gn${port}" \
                --hashlimit-above "8/sec" --hashlimit-mode srcip \
                --hashlimit-burst 20 -j DROP 2>/dev/null
        done

        for rp in 27015 25575; do
            iptables -A EG_GAME -p tcp --dport "$rp" \
                -m hashlimit --hashlimit-name "rc${rp}" \
                --hashlimit-above "5/min" --hashlimit-mode srcip \
                --hashlimit-burst 10 \
                -j LOG --log-prefix "[EG-GAME-RCON] " --log-level 4 2>/dev/null
            iptables -A EG_GAME -p tcp --dport "$rp" \
                -m hashlimit --hashlimit-name "rc${rp}" \
                --hashlimit-above "5/min" --hashlimit-mode srcip \
                --hashlimit-burst 10 -j DROP 2>/dev/null
        done

        log GAME "Game Layer aktif — portlar: $GAME_PORTS_UDP"
    fi

    # IPv6 temel
    ip6tables -A EG_L4_6 -i lo -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -m conntrack --ctstate INVALID -j DROP 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --dport 22  -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --dport 80  -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --dport 443 -j ACCEPT 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --syn \
        -m limit --limit "${L4_SYN_RATE}/s" --limit-burst "$L4_SYN_BURST" -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -p tcp --syn -j DROP 2>/dev/null
    ip6tables -A EG_L4_6 -p icmpv6 \
        -m limit --limit 50/s --limit-burst 100 -j RETURN 2>/dev/null
    ip6tables -A EG_L4_6 -p icmpv6 -j DROP 2>/dev/null

    log OK "Tüm kurallar aktif — SSH(22)+Web(80/443) EG_ACCEPT'te korunuyor"
}

rules_remove() {
    log INFO "Kurallar kaldırılıyor..."
    for c in EG_ACCEPT EG_L4 EG_L7 EG_GAME; do
        iptables -D INPUT   -j "$c" 2>/dev/null
        iptables -D FORWARD -j "$c" 2>/dev/null
        iptables -F "$c" 2>/dev/null
        iptables -X "$c" 2>/dev/null
    done
    ip6tables -D INPUT -j EG_L4_6 2>/dev/null
    ip6tables -F EG_L4_6 2>/dev/null; ip6tables -X EG_L4_6 2>/dev/null
    log OK "Tüm kurallar kaldırıldı"
}

ip_block() {
    local ip=$1 reason=${2:-manual} layer=${3:-L4}
    [[ -z "$ip" ]] && return 1
    grep -qF "$ip" "$WL" 2>/dev/null && { log WARN "Whitelist'te: $ip"; return 1; }
    iptables -C EG_L4 -s "$ip" -j DROP 2>/dev/null && return 0
    iptables -I EG_L4 1 -s "$ip" -j DROP
    log ALERT "[$layer] ENGELLENDİ: $ip — $reason"
    _jblock "$ip" "$reason" "$layer" add
    alert_push block "IP Engellendi" "$ip — $reason" high
    [[ "$BAN_TIME" -gt 0 ]] && (sleep "$BAN_TIME"; ip_unblock "$ip" ban_expired) &
}

ip_unblock() {
    local ip=$1 reason=${2:-manual}
    iptables -D EG_L4   -s "$ip" -j DROP 2>/dev/null
    iptables -D EG_ACCEPT -s "$ip" -j ACCEPT 2>/dev/null
    log INFO "Engel kaldırıldı: $ip"
    _jblock "$ip" "$reason" "" remove
}

_jblock() {
    python3 - <<PY 2>/dev/null
import json
f="$BLOCKED"
try: d=json.load(open(f))
except: d={"blocked":[]}
ts=__import__('datetime').datetime.utcnow().isoformat()+'Z'
if "$4"=="add":
    x=next((i for i in d["blocked"] if i["ip"]=="$1"),None)
    if x: x["hits"]=x.get("hits",1)+1; x["last"]="$ts"
    else: d["blocked"].insert(0,{"ip":"$1","reason":"$2","layer":"$3","time":ts,"hits":1})
    d["blocked"]=d["blocked"][:500]
else: d["blocked"]=[i for i in d["blocked"] if i["ip"]!="$1"]
json.dump(d,open(f,"w"))
PY
}

alert_push() {
    local t=$1 title=$2 detail=$3 sev=${4:-medium}
    local ts; ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    python3 - <<PY 2>/dev/null
import json
f="$ALERTS"
try: d=json.load(open(f))
except: d={"alerts":[]}
d["alerts"].insert(0,{"type":"$t","title":"$title","detail":"$detail",
  "severity":"$sev","time":"$ts","read":False})
d["alerts"]=d["alerts"][:200]
json.dump(d,open(f,"w"))
PY
    [[ -n "$WEBHOOK" ]] && {
        local icon="🔴"; [[ "$sev" == "medium" ]] && icon="🟡"; [[ "$sev" == "low" ]] && icon="🟢"
        curl -sf -X POST "$WEBHOOK" -H "Content-Type: application/json" \
            -d "{\"text\":\"$icon *Eagle Guard* — *$title*\\n$detail\"}" >/dev/null 2>&1 &
    }
    [[ -n "$TG_BOT" && -n "$TG_CHAT" ]] && \
        curl -sf "https://api.telegram.org/bot${TG_BOT}/sendMessage" \
            -d "chat_id=$TG_CHAT&text=Eagle Guard%0A$title%0A$detail" >/dev/null 2>&1 &
    [[ -n "$EMAIL" ]] && command -v mail >/dev/null 2>&1 && \
        echo "$detail" | mail -s "Eagle Guard: $title" "$EMAIL" &
}

collect() {
    local iface; iface=$(ip route 2>/dev/null | awk '/default/{print $5;exit}')
    [[ -z "$iface" ]] && iface=eth0
    local rx_b tx_b rx_p tx_p
    rx_b=$(cat /sys/class/net/$iface/statistics/rx_bytes   2>/dev/null||echo 0)
    tx_b=$(cat /sys/class/net/$iface/statistics/tx_bytes   2>/dev/null||echo 0)
    rx_p=$(cat /sys/class/net/$iface/statistics/rx_packets 2>/dev/null||echo 0)
    tx_p=$(cat /sys/class/net/$iface/statistics/tx_packets 2>/dev/null||echo 0)
    local prx ptx prxp ptxp
    prx=$(python3  -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('bytes_in',0))"  2>/dev/null||echo 0)
    ptx=$(python3  -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('bytes_out',0))" 2>/dev/null||echo 0)
    prxp=$(python3 -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('pkts_in',0))"  2>/dev/null||echo 0)
    ptxp=$(python3 -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('pkts_out',0))" 2>/dev/null||echo 0)
    local bps_in bps_out pps_in pps_out
    bps_in=$(( (rx_b-prx)/INTERVAL )); bps_out=$(( (tx_b-ptx)/INTERVAL ))
    pps_in=$(( (rx_p-prxp)/INTERVAL )); pps_out=$(( (tx_p-ptxp)/INTERVAL ))
    for v in bps_in bps_out pps_in pps_out; do [[ ${!v} -lt 0 ]] && eval "$v=0"; done
    local cpu; cpu=$(awk '{printf "%.1f",$1*100/'"$(nproc 2>/dev/null||echo 1)"'}' /proc/loadavg 2>/dev/null||echo 0)
    local mem; mem=$(free 2>/dev/null|awk '/Mem:/{printf "%.1f",$3/$2*100}'||echo 0)
    local conn; conn=$(ss -tn state established 2>/dev/null|wc -l||echo 0)
    local uptime=0
    uptime=$(python3 -c "
import json,datetime
try:
    d=json.load(open('$STATS'))
    st=d.get('start_time','')
    if st:
        from datetime import timezone
        s=datetime.datetime.fromisoformat(st.replace('Z','+00:00'))
        print(int((datetime.datetime.now(timezone.utc)-s).total_seconds()))
    else: print(0)
except: print(0)" 2>/dev/null||echo 0)
    local l4_syn l4_icmp l4_xmas l4_null l4_frag l4_scan
    local l7_http l7_https l7_ssh g_udp g_tcp g_rcon blk
    l4_syn=$(iptables  -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-SYN/{s+=$1}END{print s+0}')
    l4_icmp=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-ICMP/{s+=$1}END{print s+0}')
    l4_xmas=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-XMAS/{s+=$1}END{print s+0}')
    l4_null=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-NULL/{s+=$1}END{print s+0}')
    l4_frag=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-FRAG/{s+=$1}END{print s+0}')
    l4_scan=$(iptables -L EG_L4   -nvx 2>/dev/null|awk '/EG-L4-SCAN/{s+=$1}END{print s+0}')
    l7_http=$(iptables -L EG_L7   -nvx 2>/dev/null|awk '/EG-L7-HTTP/{s+=$1}END{print s+0}')
    l7_https=$(iptables -L EG_L7  -nvx 2>/dev/null|awk '/EG-L7-HTTPS/{s+=$1}END{print s+0}')
    l7_ssh=$(iptables  -L EG_ACCEPT -nvx 2>/dev/null|awk '/EG-SSH/{s+=$1}END{print s+0}')
    g_udp=$(iptables   -L EG_GAME -nvx 2>/dev/null|awk '/EG-GAME-UDP/{s+=$1}END{print s+0}')
    g_tcp=$(iptables   -L EG_GAME -nvx 2>/dev/null|awk '/EG-GAME-TCP/{s+=$1}END{print s+0}')
    g_rcon=$(iptables  -L EG_GAME -nvx 2>/dev/null|awk '/EG-GAME-RCON/{s+=$1}END{print s+0}')
    blk=$(iptables     -L EG_L4   -n   2>/dev/null|grep -c "^DROP"||echo 0)
    if [[ "$AUTO_BLOCK" == "yes" ]]; then
        [[ "$pps_in" -gt "$ALERT_PPS" ]] && {
            log ALERT "DDoS! PPS: $pps_in"
            alert_push ddos "DDoS Tespit!" "PPS: ${pps_in}/s" high
        }
        [[ "$bps_in" -gt "$ALERT_BPS" ]] && \
            alert_push flood "Yüksek Bant!" "$(( bps_in/1048576 )) MB/s" high
        for logf in /var/log/kern.log /var/log/syslog; do
            [[ -r "$logf" ]] || continue
            grep "EG-" "$logf" 2>/dev/null|tail -500|\
                grep -oP 'SRC=\K[\d.]+' |sort|uniq -c|sort -rn|\
                while read -r cnt ip; do
                    [[ "$cnt" -ge "$AUTOBLOCK_HITS" ]] && ip_block "$ip" "auto:${cnt}" L4
                done
        done
    fi
    local ts; ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    python3 - <<PY 2>/dev/null
import json
f="$TRAFFIC"
try: d=json.load(open(f))
except: d={"points":[]}
d["points"].append({"t":"$ts","unix":$(date +%s),
  "bps_in":$bps_in,"bps_out":$bps_out,"pps_in":$pps_in,"pps_out":$pps_out,
  "bytes_in":$rx_b,"bytes_out":$tx_b,"conn":$conn,"cpu":$cpu})
d["points"]=d["points"][-240:]
json.dump(d,open(f,"w"))
PY
    python3 - <<PY 2>/dev/null
import json
f="$STATS"
try: d=json.load(open(f))
except: d={}
d.update({"status":"active","last_update":"$ts","interface":"$iface",
  "net":{"bps_in":$bps_in,"bps_out":$bps_out,"pps_in":$pps_in,"pps_out":$pps_out,
         "bytes_in":$rx_b,"bytes_out":$tx_b,"pkts_in":$rx_p,"pkts_out":$tx_p,
         "rx_mb":round($rx_b/1048576,2),"tx_mb":round($tx_b/1048576,2)},
  "l4":{"syn":$l4_syn,"icmp":$l4_icmp,"xmas":$l4_xmas,
        "null":$l4_null,"frag":$l4_frag,"scan":$l4_scan,
        "total":$l4_syn+$l4_icmp+$l4_xmas+$l4_null+$l4_frag},
  "l7":{"http":$l7_http,"https":$l7_https,"ssh":$l7_ssh,
        "total":$l7_http+$l7_https+$l7_ssh},
  "game":{"udp_flood":$g_udp,"tcp_flood":$g_tcp,"rcon":$g_rcon,
          "total":$g_udp+$g_tcp+$g_rcon},
  "sys":{"cpu":$cpu,"mem":$mem,"conn":$conn,"uptime":$uptime},
  "blocked_rules":$blk})
json.dump(d,open(f,"w"))
PY
}

tui() {
    while true; do
        clear
        local iface; iface=$(ip route 2>/dev/null|awk '/default/{print $5;exit}')
        local blk; blk=$(iptables -L EG_L4 -n 2>/dev/null|grep -c "^DROP"||echo 0)
        local conn; conn=$(ss -tn state established 2>/dev/null|wc -l)
        local cpu; cpu=$(awk '{printf "%.0f%%",$1*100/'"$(nproc 2>/dev/null||echo 1)"'}' /proc/loadavg)
        local mem; mem=$(free 2>/dev/null|awk '/Mem:/{printf "%.0f%%",$3/$2*100}')
        local bps; bps=$(python3 -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('bps_in',0))" 2>/dev/null||echo 0)
        local pps; pps=$(python3 -c "import json;d=json.load(open('$STATS'));print(d.get('net',{}).get('pps_in',0))" 2>/dev/null||echo 0)
        echo -e "${W}"
        echo "  ╔══════════════════════════════════════════════════════════════════════╗"
        echo "  ║  Eagle Guard v5.1  ·  L4/L7/GAME  ·  SSH+Web Kesintisiz            ║"
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        printf "  ║  %-36s  %-33s║\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$(hostname) — ${iface:-eth0}"
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        printf "  ║  ${G}AKTİF${N}   Engel:${R}%-5s${N}  Conn:${C}%-5s${N}  CPU:${Y}%-7s${N}  RAM:${Y}%-7s${N}    ║\n" \
            "$blk" "$conn" "$cpu" "$mem"
        printf "  ║  IN: $(echo $bps|awk '{printf "%.2f MB/s",$1/1048576}')  PPS: $pps%-50s║\n" ""
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        echo -e "  ║  [ACCEPT] SSH:22 ✓  HTTP:80 ✓  HTTPS:443 ✓                         ║"
        echo -e "  ║  [L4]  SYN ✓  ICMP ✓  XMAS/NULL ✓  Frag ✓  Bogon ✓  Scan ✓       ║"
        echo -e "  ║  [GM]  UDP Flood ✓  TCP Flood ✓  RCON Brute ✓                      ║"
        echo "  ╠══════════════════════════════════════════════════════════════════════╣"
        echo "  ║  Web: http://$(hostname -I 2>/dev/null|awk '{print $1}')/eagle-guard/  [Q] Cikis          ║"
        echo -e "  ╚══════════════════════════════════════════════════════════════════════╝${N}"
        read -t 4 -n 1 k 2>/dev/null
        [[ "$k" == "q" || "$k" == "Q" ]] && break
    done
}

show_help() {
    echo -e "${C}Eagle Guard v5.1 — Yardim${N}"
    echo ""
    echo "KOMUTLAR:"
    echo "  eagle-guard start          Korumayı başlat"
    echo "  eagle-guard stop           Korumayı durdur"
    echo "  eagle-guard restart        Yeniden başlat"
    echo "  eagle-guard status         TUI ekranı"
    echo "  eagle-guard stats          JSON istatistik"
    echo "  eagle-guard block <IP>     IP engelle"
    echo "  eagle-guard unblock <IP>   Engeli kaldır"
    echo "  eagle-guard rules-l4       L4 kuralları"
    echo "  eagle-guard rules-l7       L7 kuralları"
    echo "  eagle-guard rules-game     Game kuralları"
    echo "  eagle-guard rules-accept   ACCEPT kuralları"
    echo "  eagle-guard logs [N]       Son N log"
    echo "  eagle-guard game-on        Game korumasını aç"
    echo "  eagle-guard game-off       Game korumasını kapat"
    echo "  eagle-guard help           Bu ekran"
    echo ""
    echo "DOSYALAR:"
    echo "  /opt/eagle-guard/config/eagle.conf    Konfigürasyon"
    echo "  /opt/eagle-guard/config/whitelist.txt Engellenmeyen IP'ler"
    echo "  /opt/eagle-guard/logs/eagle.log       Log dosyası"
    echo "  /opt/eagle-guard/data/stats.json      Canlı istatistik"
    echo "  /opt/eagle-guard/uninstall.sh         Tamamen kaldır"
    echo ""
    echo "WEB: http://$(hostname -I 2>/dev/null|awk '{print $1}')/eagle-guard/"
}

case "${1:-help}" in
    start)
        [[ -f "$PID" ]] && kill -0 "$(cat $PID)" 2>/dev/null && \
            { echo -e "${Y}Zaten çalışıyor (PID: $(cat $PID))${N}"; exit 0; }
        load_conf; setup; kernel_harden; apply_rules
        echo $$ > "$PID"
        python3 -c "
import json,datetime
f='$STATS'
try: d=json.load(open(f))
except: d={}
d['status']='active'
d['start_time']=datetime.datetime.utcnow().isoformat()+'Z'
json.dump(d,open(f,'w'))" 2>/dev/null || true
        log OK "Eagle Guard v5.1 baslatildi (PID:$$) — SSH+Web kesintisiz"
        alert_push system "Eagle Guard v5.1 Baslatildi" "L4+L7+Game aktif" low
        while true; do load_conf; collect; sleep "$INTERVAL"; done
        ;;
    stop)
        load_conf; setup; rules_remove; kernel_reset
        python3 -c "
import json
try:
    d=json.load(open('$STATS')); d['status']='inactive'
    json.dump(d,open('$STATS','w'))
except: pass" 2>/dev/null || true
        alert_push system "Eagle Guard Durduruldu" "Koruma devre disi" medium
        kill "$(cat $PID 2>/dev/null)" 2>/dev/null || true
        rm -f "$PID"
        log OK "Eagle Guard durduruldu"
        ;;
    restart)   "$0" stop; sleep 2; exec "$0" start ;;
    status)    load_conf; setup; tui ;;
    block)     [[ -z "$2" ]] && { show_help; exit 1; }; load_conf; setup; ip_block "$2" "${3:-cli}" "${4:-L4}" ;;
    unblock)   [[ -z "$2" ]] && { show_help; exit 1; }; load_conf; setup; ip_unblock "$2" cli ;;
    stats)     python3 -m json.tool "$STATS" 2>/dev/null || echo "Stats bulunamadi" ;;
    rules-l4)      iptables -L EG_L4     -nvx 2>/dev/null || echo "EG_L4 bulunamadi" ;;
    rules-l7)      iptables -L EG_L7     -nvx 2>/dev/null || echo "EG_L7 bulunamadi" ;;
    rules-game)    iptables -L EG_GAME   -nvx 2>/dev/null || echo "EG_GAME bulunamadi" ;;
    rules-accept)  iptables -L EG_ACCEPT -nvx 2>/dev/null || echo "EG_ACCEPT bulunamadi" ;;
    logs)      tail -"${2:-100}" "$LOG" 2>/dev/null || echo "Log bulunamadi" ;;
    game-on)
        load_conf; setup
        for c in EG_GAME; do
            iptables -D INPUT -j "$c" 2>/dev/null
            iptables -F "$c" 2>/dev/null; iptables -X "$c" 2>/dev/null
            iptables -N "$c"; iptables -I INPUT 4 -j "$c"
        done
        GAME_ENABLED=yes
        [[ -f "$CONF" ]] && source "$CONF" 2>/dev/null || true
        # Game kurallarını uygula
        iptables -A EG_GAME -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
        IFS=',' read -ra UPORTS <<< "$GAME_PORTS_UDP"
        for port in "${UPORTS[@]}"; do
            port=$(echo "$port"|tr -d ' '); [[ -z "$port" ]] && continue
            iptables -A EG_GAME -p udp --dport "$port" \
                -m hashlimit --hashlimit-name "gu${port}" \
                --hashlimit-above "${GAME_UDP_PPS}/sec" \
                --hashlimit-mode srcip --hashlimit-burst "$GAME_UDP_BURST" -j DROP 2>/dev/null
        done
        log OK "Game korumasi etkinlestirildi"
        ;;
    game-off)
        iptables -D INPUT -j EG_GAME 2>/dev/null
        iptables -F EG_GAME 2>/dev/null; iptables -X EG_GAME 2>/dev/null
        log OK "Game korumasi devre disi"
        ;;
    help|--help|-h) show_help ;;
    *) echo "Bilinmeyen: $1"; show_help ;;
esac
